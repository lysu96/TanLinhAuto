<?php
declare(strict_types=1);
$config=require __DIR__.'/../config/config.php';
require __DIR__.'/../app/Core/Database.php';
require __DIR__.'/../app/Core/View.php';
require __DIR__.'/../app/Core/Auth.php';
require __DIR__.'/../app/Core/Permissions.php';
require __DIR__.'/../app/Core/Audit.php';
require __DIR__.'/../app/Models/AuthModel.php';
require __DIR__.'/../app/Models/Reports.php';
require __DIR__.'/../app/Models/Settings.php';
require __DIR__.'/../app/Controllers/AuthController.php';
require __DIR__.'/../app/Models/Employees.php';
require __DIR__.'/../app/Models/AuditLog.php';
require __DIR__.'/../app/Controllers/AuditController.php';
require __DIR__.'/../app/Controllers/EmployeesController.php';
require __DIR__.'/../app/Controllers/ReportsController.php';
require __DIR__.'/../app/Controllers/SettingsController.php';
require __DIR__.'/../app/Models/Dashboard.php';
require __DIR__.'/../app/Models/KhachHang.php';
require __DIR__.'/../app/Models/Xe.php';
require __DIR__.'/../app/Models/PhieuSuaChua.php';
require __DIR__.'/../app/Models/HoaDon.php';
require __DIR__.'/../app/Models/HangHoa.php';
require __DIR__.'/../app/Controllers/HomeController.php';
require __DIR__.'/../app/Controllers/KhachHangController.php';
require __DIR__.'/../app/Controllers/XeController.php';
require __DIR__.'/../app/Controllers/PhieuSuaChuaController.php';
require __DIR__.'/../app/Controllers/HoaDonController.php';
require __DIR__.'/../app/Controllers/HangHoaController.php';
$db=Database::get($config['db']);
Auth::start();
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH) ?: '/';
$base=rtrim($config['base_url'],'/');
$route=substr($path,0,strlen($base))===$base ? substr($path,strlen($base)) : $path;
$route=rtrim($route,'/') ?: '/';
if($route==='/dang-nhap'){(new AuthController($db))->login();exit;}
if($route==='/thiet-lap-tai-khoan'){(new AuthController($db))->setup();exit;}
if($route==='/dang-xuat'){(new AuthController($db))->logout();exit;}
if(!Auth::check()){header('Location: '.$base.'/dang-nhap');exit;}
if($route==='/api/search'){
    header('Content-Type: application/json; charset=utf-8');
    $q=trim((string)($_GET['q']??''));
    if(mb_strlen($q)<2){echo json_encode(['customers'=>[],'vehicles'=>[]],JSON_UNESCAPED_UNICODE);exit;}
    echo json_encode(['customers'=>Permissions::can('customers')?(new KhachHang($db))->search($q,8):[],'vehicles'=>Permissions::can('vehicles')?(new Xe($db))->search($q,8):[]],JSON_UNESCAPED_UNICODE);exit;
}
if($route==='/') { Permissions::require('dashboard'); (new HomeController($db))->index(); exit; }
if($route==='/nhat-ky') { (new AuditController($db))->index(); exit; }
if($route==='/nhan-vien' || $route==='/nhan-vien/') { (new EmployeesController($db))->index(); exit; }
if($route==='/nhan-vien/them') { (new EmployeesController($db))->create(); exit; }
if(preg_match('#^/nhan-vien/(\d+)/sua$#',$route,$m)) { (new EmployeesController($db))->edit((int)$m[1]); exit; }
if(preg_match('#^/nhan-vien/(\d+)/doi-trang-thai$#',$route,$m)) { (new EmployeesController($db))->toggle((int)$m[1]); exit; }
if(preg_match('#^/nhan-vien/(\d+)$#',$route,$m)) { (new EmployeesController($db))->show((int)$m[1]); exit; }
if($route==='/hoa-don' || $route==='/hoa-don/') { Permissions::require('invoices'); (new HoaDonController($db))->index(); exit; }
if($route==='/hoa-don/them') { Permissions::require('invoices'); (new HoaDonController($db))->create(); exit; }
if(preg_match('#^/hoa-don/(\d+)/in$#',$route,$m)) { Permissions::require('invoices'); (new HoaDonController($db))->print((int)$m[1]); exit; }
if(preg_match('#^/hoa-don/(\d+)$#',$route,$m)) { Permissions::require('invoices'); (new HoaDonController($db))->show((int)$m[1]); exit; }
if($route==='/bao-cao' || $route==='/bao-cao/') { Permissions::require('reports'); (new ReportsController($db))->index(); exit; }
if($route==='/cai-dat' || $route==='/cai-dat/') { (new SettingsController($db))->index(); exit; }
if($route==='/cong-no' || $route==='/cong-no/') { Permissions::require('debt'); (new HoaDonController($db))->debt(); exit; }
if($route==='/hang-hoa' || $route==='/hang-hoa/') { Permissions::require('inventory'); (new HangHoaController($db))->index(); exit; }
if($route==='/hang-hoa/them') { Permissions::require('inventory'); (new HangHoaController($db))->create(); exit; }
if($route==='/hang-hoa/phieu-kho') { Permissions::require('inventory'); (new HangHoaController($db))->receipt(); exit; }
if(preg_match('#^/hang-hoa/phieu-kho/(\d+)/in$#',$route,$m)) { Permissions::require('inventory'); (new HangHoaController($db))->print((int)$m[1]); exit; }
if(preg_match('#^/hang-hoa/phieu-kho/(\d+)$#',$route,$m)) { Permissions::require('inventory'); (new HangHoaController($db))->movement((int)$m[1]); exit; }
if(preg_match('#^/hang-hoa/(\d+)/sua$#',$route,$m)) { Permissions::require('inventory_manage'); (new HangHoaController($db))->edit((int)$m[1]); exit; }
if(preg_match('#^/hang-hoa/(\d+)$#',$route,$m)) { Permissions::require('inventory'); (new HangHoaController($db))->show((int)$m[1]); exit; }
if($route==='/khach-hang' || $route==='/khach-hang/') { Permissions::require('customers'); (new KhachHangController($db))->index(); exit; }
if($route==='/khach-hang/them') { Permissions::require('customers'); (new KhachHangController($db))->create(); exit; }
if(preg_match('#^/khach-hang/(\d+)$#',$route,$m)) { Permissions::require('customers'); (new KhachHangController($db))->show((int)$m[1]); exit; }
if($route==='/phieu-sua' || $route==='/phieu-sua/') { Permissions::require('repairs'); (new PhieuSuaChuaController($db))->index(); exit; }
if($route==='/phieu-sua/them') { Permissions::require('repairs'); (new PhieuSuaChuaController($db))->create(); exit; }
if(preg_match('#^/phieu-sua/(\d+)/in$#',$route,$m)) { Permissions::require('repairs'); (new PhieuSuaChuaController($db))->print((int)$m[1]); exit; }
if(preg_match('#^/phieu-sua/(\d+)$#',$route,$m)) { Permissions::require('repairs'); (new PhieuSuaChuaController($db))->show((int)$m[1]); exit; }
if($route==='/xe' || $route==='/xe/') { Permissions::require('vehicles'); (new XeController($db))->index(); exit; }
if($route==='/xe/them') { Permissions::require('vehicles'); $_GET['mode']=$_GET['mode']??'existing'; (new KhachHangController($db))->create(); exit; }
if(preg_match('#^/xe/(\d+)$#',$route,$m)) { Permissions::require('vehicles'); (new XeController($db))->show((int)$m[1]); exit; }
http_response_code(404); echo '<h1>404 - Không tìm thấy trang</h1>';
