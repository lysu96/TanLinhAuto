<?php
declare(strict_types=1);
final class Reports {
    public function __construct(private PDO $db) {}
    public function summary(string $from,string $to): array {
        $fromDt=$from.' 00:00:00'; $toDt=$to.' 23:59:59';
        $q=$this->db->prepare("SELECT COALESCE(SUM(tong_tien-giam_gia),0) FROM hoa_don WHERE ngay_lap BETWEEN ? AND ? AND trang_thai<>'HUY'");$q->execute([$fromDt,$toDt]);$revenue=(float)$q->fetchColumn();
        $q=$this->db->prepare("SELECT COALESCE(SUM(so_tien),0) FROM thanh_toan WHERE ngay_thanh_toan BETWEEN ? AND ?");$q->execute([$fromDt,$toDt]);$paid=(float)$q->fetchColumn();
        $debt=(float)$this->db->query("SELECT COALESCE(SUM(tong_con_no),0) FROM v_cong_no_khach_hang")->fetchColumn();
        $inventory=(float)$this->db->query("SELECT COALESCE(SUM(ton_kho*gia_nhap),0) FROM hang_hoa WHERE trang_thai=1 AND quan_ly_ton_kho=1")->fetchColumn();
        $low=(int)$this->db->query("SELECT COUNT(*) FROM hang_hoa WHERE trang_thai=1 AND quan_ly_ton_kho=1 AND ton_kho<=muc_ton_toi_thieu")->fetchColumn();
        $q=$this->db->prepare("SELECT COUNT(*) FROM phieu_sua_chua WHERE ngay_tiep_nhan BETWEEN ? AND ? AND trang_thai<>'HUY'");$q->execute([$fromDt,$toDt]);$repairs=(int)$q->fetchColumn();
        return compact('revenue','paid','debt','inventory','low','repairs');
    }
    public function daily(string $from,string $to): array {
        $st=$this->db->prepare("SELECT DATE(ngay_lap) ngay, COUNT(*) so_hoa_don, COALESCE(SUM(tong_tien-giam_gia),0) doanh_thu, COALESCE(SUM(da_thanh_toan),0) da_thu
            FROM hoa_don WHERE ngay_lap BETWEEN ? AND ? AND trang_thai<>'HUY' GROUP BY DATE(ngay_lap) ORDER BY ngay DESC");$st->execute([$from.' 00:00:00',$to.' 23:59:59']);return $st->fetchAll();
    }
    public function topItems(string $from,string $to): array {
        $st=$this->db->prepare("SELECT ct.ten_hang_snapshot ten_hang, SUM(ct.so_luong) so_luong, SUM(ct.thanh_tien) doanh_thu
            FROM chi_tiet_hoa_don ct JOIN hoa_don h ON h.hoa_don_id=ct.hoa_don_id
            WHERE h.ngay_lap BETWEEN ? AND ? AND h.trang_thai<>'HUY' GROUP BY ct.ten_hang_snapshot ORDER BY doanh_thu DESC LIMIT 10");$st->execute([$from.' 00:00:00',$to.' 23:59:59']);return $st->fetchAll();
    }
    public function repairStatus(): array { return $this->db->query("SELECT trang_thai,COUNT(*) so_luong FROM phieu_sua_chua GROUP BY trang_thai ORDER BY so_luong DESC")->fetchAll(); }
}
