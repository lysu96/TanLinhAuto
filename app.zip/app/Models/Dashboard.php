<?php
declare(strict_types=1);
final class Dashboard {
    public function __construct(private PDO $db) {}
    public function stats(): array {
        return [
            'customers' => (int)$this->db->query("SELECT COUNT(*) FROM khach_hang WHERE trang_thai=1")->fetchColumn(),
            'vehicles' => (int)$this->db->query("SELECT COUNT(*) FROM xe WHERE trang_thai=1")->fetchColumn(),
            'repairing' => (int)$this->db->query("SELECT COUNT(*) FROM phieu_sua_chua WHERE trang_thai IN ('TIEP_NHAN','DANG_KIEM_TRA','BAO_GIA','CHO_DUYET','DANG_SUA')")->fetchColumn(),
            'debt' => (float)$this->db->query("SELECT COALESCE(SUM(con_no),0) FROM hoa_don WHERE trang_thai <> 'HUY'")->fetchColumn(),
        ];
    }
    public function chart(): array {
        $st=$this->db->query("SELECT DATE(ngay_lap) ngay, COALESCE(SUM(tong_tien-giam_gia),0) doanh_thu, COALESCE(SUM(da_thanh_toan),0) da_thu FROM hoa_don WHERE ngay_lap >= DATE_SUB(CURDATE(), INTERVAL 13 DAY) AND trang_thai<>'HUY' GROUP BY DATE(ngay_lap) ORDER BY ngay");
        $rows=$st->fetchAll(); $map=[]; foreach($rows as $r){$map[$r['ngay']]=$r;} $labels=[];$revenue=[];$paid=[]; for($i=13;$i>=0;$i--){$d=date('Y-m-d',strtotime('-'.$i.' day'));$labels[]=$d;$revenue[]=(float)($map[$d]['doanh_thu']??0);$paid[]=(float)($map[$d]['da_thu']??0);}
        $status=$this->db->query("SELECT trang_thai,COUNT(*) so_luong FROM phieu_sua_chua WHERE trang_thai<>'HUY' GROUP BY trang_thai ORDER BY so_luong DESC")->fetchAll();
        return ['labels'=>$labels,'revenue'=>$revenue,'paid'=>$paid,'status'=>$status];
    }
    public function recentRepairs(): array {
        $sql = "SELECT p.ma_phieu,p.ngay_tiep_nhan,p.trang_thai,k.ho_ten,x.bien_so_hien_tai
                FROM phieu_sua_chua p JOIN khach_hang k ON k.khach_hang_id=p.khach_hang_id
                JOIN xe x ON x.xe_id=p.xe_id ORDER BY p.phieu_sua_id DESC LIMIT 8";
        return $this->db->query($sql)->fetchAll();
    }
}
