<?php
declare(strict_types=1);
final class AuditLog {
    public function __construct(private PDO $db) {}
    public function list(string $q='',int $limit=100): array {
        try {
            $where=[];$args=[];
            if($q!==''){ $where[]='(nk.mo_dun LIKE ? OR nk.hanh_dong LIKE ? OR nk.mo_ta LIKE ? OR nv.ho_ten LIKE ?)';$x="%$q%";array_push($args,$x,$x,$x,$x); }
            $sql="SELECT nk.*,tk.ten_dang_nhap,nv.ho_ten FROM nhat_ky_he_thong nk LEFT JOIN tai_khoan tk ON tk.tai_khoan_id=nk.tai_khoan_id LEFT JOIN nhan_vien nv ON nv.nhan_vien_id=tk.nhan_vien_id";if($where)$sql.=' WHERE '.implode(' AND ',$where);$sql.=' ORDER BY nk.nhat_ky_id DESC LIMIT '.max(1,min($limit,500));$st=$this->db->prepare($sql);$st->execute($args);return $st->fetchAll();
        } catch(Throwable $e) { return []; }
    }
}
