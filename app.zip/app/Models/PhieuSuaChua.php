<?php
declare(strict_types=1);
final class PhieuSuaChua {
 public function __construct(private PDO $db) {}
 public function list(string $q='',string $status=''):array{$sql="SELECT p.*,k.ma_kh,k.ho_ten,x.ma_xe,x.bien_so_hien_tai,x.nhan_hieu,x.model,COALESCE((SELECT SUM(ct.thanh_tien) FROM chi_tiet_sua_chua ct WHERE ct.phieu_sua_id=p.phieu_sua_id AND ct.trang_thai<>'HUY'),0) tong_dich_vu FROM phieu_sua_chua p JOIN khach_hang k ON k.khach_hang_id=p.khach_hang_id JOIN xe x ON x.xe_id=p.xe_id WHERE 1=1";$p=[];if($q!==''){$l="%$q%";$sql.=" AND (p.ma_phieu LIKE ? OR k.ho_ten LIKE ? OR k.ma_kh LIKE ? OR x.bien_so_hien_tai LIKE ? OR x.ma_xe LIKE ?)";$p=[$l,$l,$l,$l,$l];}if($status!==''){$sql.=" AND p.trang_thai=?";$p[]=$status;}$sql.=" ORDER BY p.phieu_sua_id DESC LIMIT 100";$st=$this->db->prepare($sql);$st->execute($p);return $st->fetchAll();}
 public function customers():array{return $this->db->query("SELECT khach_hang_id,ma_kh,ho_ten,so_dien_thoai FROM khach_hang WHERE trang_thai=1 ORDER BY ho_ten")->fetchAll();}
 public function vehiclesForCustomer(int $id):array{$st=$this->db->prepare("SELECT x.xe_id,x.ma_xe,x.bien_so_hien_tai,x.nhan_hieu,x.model FROM xe x JOIN lich_su_so_huu_xe ls ON ls.xe_id=x.xe_id WHERE ls.khach_hang_id=? AND ls.la_chu_hien_tai=1 AND x.trang_thai=1 ORDER BY x.bien_so_hien_tai");$st->execute([$id]);return $st->fetchAll();}
 public function create(array $d):int{$kh=(int)($d['khach_hang_id']??0);$xe=(int)($d['xe_id']??0);if(!$kh||!$xe)throw new RuntimeException('Vui lòng chọn khách hàng và xe.');$st=$this->db->prepare('SELECT 1 FROM lich_su_so_huu_xe WHERE xe_id=? AND khach_hang_id=? AND la_chu_hien_tai=1');$st->execute([$xe,$kh]);if(!$st->fetchColumn())throw new RuntimeException('Xe này hiện không thuộc khách hàng đã chọn.');$this->db->beginTransaction();try{$st=$this->db->prepare("INSERT INTO phieu_sua_chua(ma_phieu,khach_hang_id,xe_id,ngay_du_kien_hoan_thanh,km_tiep_nhan,nhien_lieu,noi_dung_yeu_cau,ghi_chu) VALUES(LEFT(UUID(),30),?,?,?,?,?,?,?)");$st->execute([$kh,$xe,trim((string)($d['ngay_du_kien_hoan_thanh']??''))?:null,($d['km_tiep_nhan']??'')!==''?(int)$d['km_tiep_nhan']:null,trim((string)($d['nhien_lieu']??''))?:null,trim((string)($d['noi_dung_yeu_cau']??''))?:null,trim((string)($d['ghi_chu']??''))?:null]);$id=(int)$this->db->lastInsertId();$this->db->prepare('UPDATE phieu_sua_chua SET ma_phieu=? WHERE phieu_sua_id=?')->execute(['SC'.str_pad((string)$id,5,'0',STR_PAD_LEFT),$id]);$this->db->commit();return $id;}catch(Throwable $e){$this->db->rollBack();throw $e;}}
 public function detail(int $id):?array{$st=$this->db->prepare("SELECT p.*,k.ma_kh,k.ho_ten,k.so_dien_thoai,k.dia_chi,x.ma_xe,x.bien_so_hien_tai,x.nhan_hieu,x.model,x.nam_san_xuat FROM phieu_sua_chua p JOIN khach_hang k ON k.khach_hang_id=p.khach_hang_id JOIN xe x ON x.xe_id=p.xe_id WHERE p.phieu_sua_id=?");$st->execute([$id]);$repair=$st->fetch();if(!$repair)return null;$st=$this->db->prepare("SELECT ct.*,h.ma_hang,h.ten_hang FROM chi_tiet_sua_chua ct LEFT JOIN hang_hoa h ON h.hang_hoa_id=ct.hang_hoa_id WHERE ct.phieu_sua_id=? ORDER BY ct.chi_tiet_sua_id");$st->execute([$id]);$items=$st->fetchAll();$total=array_sum(array_map(fn($r)=>(float)$r['thanh_tien'],$items));$st=$this->db->prepare("SELECT hoa_don_id,so_hoa_don,ngay_lap,tong_tien,giam_gia,da_thanh_toan,con_no,trang_thai FROM hoa_don WHERE phieu_sua_id=? ORDER BY hoa_don_id DESC");$st->execute([$id]);$invoices=$st->fetchAll();$st=$this->db->prepare("SELECT pk.ma_phieu,pk.loai_phieu,pk.ngay_lap,pk.ly_do,ct.so_luong,ct.don_gia,h.ma_hang,h.ten_hang FROM phieu_kho pk JOIN chi_tiet_phieu_kho ct ON ct.phieu_kho_id=pk.phieu_kho_id JOIN hang_hoa h ON h.hang_hoa_id=ct.hang_hoa_id WHERE pk.tham_chieu LIKE ? OR pk.tham_chieu LIKE ? ORDER BY pk.phieu_kho_id DESC");$st->execute(["PHIEU_SUA:$id:%","REV:PHIEU_SUA:$id:%"]);$stock=$st->fetchAll();return compact('repair','items','total','invoices','stock');}
 public function updateStatus(int $id,string $status):void{
  $allowed=['TIEP_NHAN','DANG_KIEM_TRA','BAO_GIA','CHO_DUYET','DANG_SUA','HOAN_THANH','DA_GIAO_XE','HUY'];
  if(!in_array($status,$allowed,true))throw new RuntimeException('Trạng thái không hợp lệ.');
  $this->db->beginTransaction();
  try{
    $st=$this->db->prepare("SELECT trang_thai FROM phieu_sua_chua WHERE phieu_sua_id=? FOR UPDATE");$st->execute([$id]);$cur=$st->fetchColumn();
    if($cur===false)throw new RuntimeException('Không tìm thấy phiếu sửa chữa.');
    if($cur==='HUY'&&$status!=='HUY')throw new RuntimeException('Phiếu đã hủy, không thể đổi trạng thái.');
    if($status==='HUY'&&$cur!=='HUY'){
      $st=$this->db->prepare("SELECT COUNT(*) FROM hoa_don WHERE phieu_sua_id=? AND trang_thai<>'HUY'");$st->execute([$id]);
      if((int)$st->fetchColumn()>0)throw new RuntimeException('Phiếu đã có hóa đơn, không thể hủy.');
      $st=$this->db->prepare("SELECT chi_tiet_sua_id,hang_hoa_id,so_luong FROM chi_tiet_sua_chua WHERE phieu_sua_id=? AND loai='PHU_TUNG' AND hang_hoa_id IS NOT NULL AND trang_thai<>'HUY'");$st->execute([$id]);
      foreach($st->fetchAll() as $it){$this->reverseStock((int)$it['hang_hoa_id'],(float)$it['so_luong'],"PHIEU_SUA:$id:CT:{$it['chi_tiet_sua_id']}",'Hoàn phụ tùng do hủy phiếu sửa chữa');}
    }
    $this->db->prepare("UPDATE phieu_sua_chua SET trang_thai=?,ngay_hoan_thanh=CASE WHEN ?='HOAN_THANH' THEN COALESCE(ngay_hoan_thanh,NOW()) ELSE ngay_hoan_thanh END WHERE phieu_sua_id=?")->execute([$status,$status,$id]);
    $this->db->commit();
  }catch(Throwable $e){$this->db->rollBack();throw $e;}
 }
 public function addItem(int $repairId,array $d):void{$name=trim((string)($d['ten_hang_snapshot']??''));$qty=(float)($d['so_luong']??0);$price=(float)($d['don_gia']??0);$discount=(float)($d['giam_gia']??0);if($name===''||$qty<=0||$price<0||$discount<0||$discount>$qty*$price)throw new RuntimeException('Dữ liệu hạng mục không hợp lệ.');$type=in_array(($d['loai']??'DICH_VU'),['DICH_VU','PHU_TUNG','KHAC'],true)?$d['loai']:'DICH_VU';$productId=($d['hang_hoa_id']??'')!==''?(int)$d['hang_hoa_id']:null;if($type==='PHU_TUNG'&&!$productId)throw new RuntimeException('Hạng mục phụ tùng phải chọn hàng hóa trong kho.');$this->db->beginTransaction();try{$chk=$this->db->prepare("SELECT p.trang_thai,(SELECT COUNT(*) FROM hoa_don h WHERE h.phieu_sua_id=p.phieu_sua_id AND h.trang_thai<>'HUY') inv FROM phieu_sua_chua p WHERE p.phieu_sua_id=? FOR UPDATE");$chk->execute([$repairId]);$rp=$chk->fetch();if(!$rp)throw new RuntimeException('Không tìm thấy phiếu sửa chữa.');if($rp['trang_thai']==='HUY')throw new RuntimeException('Phiếu đã hủy, không thể thêm hạng mục.');if((int)$rp['inv']>0)throw new RuntimeException('Phiếu đã có hóa đơn, không thể thêm hạng mục.');$unit=trim((string)($d['don_vi_snapshot']??''))?:null;if($productId){$st=$this->db->prepare("SELECT ten_hang,COALESCE((SELECT ten_don_vi FROM don_vi_tinh dv WHERE dv.don_vi_id=h.don_vi_id),'') don_vi,gia_ban,ton_kho,quan_ly_ton_kho FROM hang_hoa h WHERE h.hang_hoa_id=? AND h.trang_thai=1 FOR UPDATE");$st->execute([$productId]);$h=$st->fetch();if(!$h)throw new RuntimeException('Phụ tùng không tồn tại hoặc đã ngừng kinh doanh.');if($type==='PHU_TUNG'&&(int)$h['quan_ly_ton_kho']===1&&(float)$h['ton_kho']<$qty)throw new RuntimeException('Không đủ tồn kho cho phụ tùng này.');$name=(string)$h['ten_hang'];$unit=$unit?:($h['don_vi']?:null);$price=$price>0?$price:(float)$h['gia_ban'];}$st=$this->db->prepare("INSERT INTO chi_tiet_sua_chua(phieu_sua_id,hang_hoa_id,ten_hang_snapshot,don_vi_snapshot,loai,so_luong,don_gia,giam_gia,ghi_chu) VALUES (?,?,?,?,?,?,?,?,?)");$st->execute([$repairId,$productId,$name,$unit,$type,$qty,$price,$discount,trim((string)($d['ghi_chu']??''))?:null]);$itemId=(int)$this->db->lastInsertId();if($type==='PHU_TUNG'&&$productId)$this->issueStock($productId,$qty,$price,"PHIEU_SUA:$repairId:CT:$itemId");$this->db->commit();}catch(Throwable $e){$this->db->rollBack();throw $e;}}
 private function issueStock(int $productId,float $qty,float $price,string $ref):void{$st=$this->db->prepare("SELECT ton_kho,quan_ly_ton_kho FROM hang_hoa WHERE hang_hoa_id=? FOR UPDATE");$st->execute([$productId]);$h=$st->fetch();if(!$h)throw new RuntimeException('Không tìm thấy hàng hóa.');if((int)$h['quan_ly_ton_kho']===1&&(float)$h['ton_kho']<$qty)throw new RuntimeException('Không đủ tồn kho để xuất phụ tùng.');$st=$this->db->prepare("INSERT INTO phieu_kho(ma_phieu,loai_phieu,ly_do,tham_chieu) VALUES(LEFT(UUID(),30), 'XUAT', ?, ?)");$st->execute(['Xuất phụ tùng cho phiếu sửa chữa',$ref]);$pid=(int)$this->db->lastInsertId();$this->db->prepare("UPDATE phieu_kho SET ma_phieu=? WHERE phieu_kho_id=?")->execute(['XK'.str_pad((string)$pid,5,'0',STR_PAD_LEFT),$pid]);$this->db->prepare("INSERT INTO chi_tiet_phieu_kho(phieu_kho_id,hang_hoa_id,so_luong,don_gia,ghi_chu) VALUES(?,?,?,?,?)")->execute([$pid,$productId,$qty,$price,'Tự động từ phiếu sửa chữa']);if((int)$h['quan_ly_ton_kho']===1)$this->db->prepare("UPDATE hang_hoa SET ton_kho=ton_kho-? WHERE hang_hoa_id=?")->execute([$qty,$productId]);}
 public function currentOwnerId(int $xeId):int{$st=$this->db->prepare("SELECT ls.khach_hang_id FROM lich_su_so_huu_xe ls JOIN khach_hang k ON k.khach_hang_id=ls.khach_hang_id WHERE ls.xe_id=? AND ls.la_chu_hien_tai=1 AND k.trang_thai=1 LIMIT 1");$st->execute([$xeId]);return (int)$st->fetchColumn();}
 /** Sửa trực tiếp nhiều hạng mục cùng lúc. $rows = [chi_tiet_sua_id => [ten_hang_snapshot,loai,so_luong,don_gia,giam_gia]]. Tự đồng bộ kho cho phụ tùng. */
 public function updateItems(int $repairId,array $rows):int{
  if(!$rows)throw new RuntimeException('Không có hạng mục nào để lưu.');
  $this->db->beginTransaction();
  try{
    $st=$this->db->prepare("SELECT p.trang_thai,(SELECT COUNT(*) FROM hoa_don h WHERE h.phieu_sua_id=p.phieu_sua_id AND h.trang_thai<>'HUY') inv FROM phieu_sua_chua p WHERE p.phieu_sua_id=? FOR UPDATE");$st->execute([$repairId]);$rp=$st->fetch();
    if(!$rp)throw new RuntimeException('Không tìm thấy phiếu sửa chữa.');
    if($rp['trang_thai']==='HUY')throw new RuntimeException('Phiếu đã hủy, không thể sửa hạng mục.');
    if((int)$rp['inv']>0)throw new RuntimeException('Phiếu đã có hóa đơn, không thể sửa hạng mục.');
    $changed=0;
    foreach($rows as $itemId=>$r){
      $itemId=(int)$itemId;if($itemId<=0||!is_array($r))continue;
      $st=$this->db->prepare("SELECT * FROM chi_tiet_sua_chua WHERE chi_tiet_sua_id=? AND phieu_sua_id=? FOR UPDATE");$st->execute([$itemId,$repairId]);$old=$st->fetch();
      if(!$old)throw new RuntimeException('Hạng mục không thuộc phiếu này hoặc đã bị xóa. Hãy tải lại trang.');
      $name=trim((string)($r['ten_hang_snapshot']??''));
      $type=in_array(($r['loai']??''),['DICH_VU','PHU_TUNG','KHAC'],true)?(string)$r['loai']:(string)$old['loai'];
      $qty=round((float)str_replace(',','.',(string)($r['so_luong']??'0')),3);
      $price=round((float)str_replace(',','.',(string)($r['don_gia']??'0')),2);
      $disc=round((float)str_replace(',','.',(string)($r['giam_gia']??'0')),2);
      if($name==='')throw new RuntimeException('Tên hạng mục không được để trống.');
      if($qty<=0)throw new RuntimeException("Số lượng của \"$name\" phải lớn hơn 0.");
      if($price<0||$disc<0)throw new RuntimeException("Đơn giá và giảm giá của \"$name\" không được âm.");
      if($disc>round($qty*$price,2))throw new RuntimeException("Giảm giá của \"$name\" lớn hơn thành tiền.");
      $productId=$old['hang_hoa_id']!==null?(int)$old['hang_hoa_id']:0;
      if($type==='PHU_TUNG'&&!$productId)throw new RuntimeException("\"$name\" chưa gắn phụ tùng trong kho nên không thể đổi sang loại Phụ tùng. Hãy xóa và thêm lại từ danh sách phụ tùng.");
      $oldIssued=($old['loai']==='PHU_TUNG'&&$productId)?(float)$old['so_luong']:0.0;
      $newIssued=($type==='PHU_TUNG'&&$productId)?$qty:0.0;
      $same=$name===(string)$old['ten_hang_snapshot']&&$type===(string)$old['loai']&&abs($qty-(float)$old['so_luong'])<0.0005&&abs($price-(float)$old['don_gia'])<0.005&&abs($disc-(float)$old['giam_gia'])<0.005;
      if($same)continue;
      $ref="PHIEU_SUA:$repairId:CT:$itemId";$delta=round($newIssued-$oldIssued,3);
      if($delta>0)$this->issueStock($productId,$delta,$price,$ref);
      elseif($delta<0)$this->reverseStock($productId,-$delta,$ref,'Hoàn phụ tùng do sửa hạng mục phiếu sửa chữa');
      $this->db->prepare("UPDATE chi_tiet_sua_chua SET ten_hang_snapshot=?,loai=?,so_luong=?,don_gia=?,giam_gia=? WHERE chi_tiet_sua_id=?")->execute([$name,$type,$qty,$price,$disc,$itemId]);
      $changed++;
    }
    $this->db->commit();return $changed;
  }catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}
 }
 /** Xóa phiếu sửa chữa/tiếp nhận. Chỉ khi chưa có hóa đơn. Phụ tùng đã xuất kho được hoàn lại (trừ phiếu đã hủy vì khi hủy đã hoàn rồi). */
 public function deleteRepair(int $id):array{
  $this->db->beginTransaction();
  try{
    $st=$this->db->prepare("SELECT ma_phieu,trang_thai FROM phieu_sua_chua WHERE phieu_sua_id=? FOR UPDATE");$st->execute([$id]);$p=$st->fetch();
    if(!$p)throw new RuntimeException('Không tìm thấy phiếu sửa chữa (có thể đã bị xóa).');
    $st=$this->db->prepare("SELECT COUNT(*) FROM hoa_don WHERE phieu_sua_id=?");$st->execute([$id]);
    if((int)$st->fetchColumn()>0)throw new RuntimeException('Phiếu đã có hóa đơn (kể cả hóa đơn đã hủy) nên không thể xóa. Hãy xóa hóa đơn liên quan trước.');
    $st=$this->db->prepare("SELECT chi_tiet_sua_id,hang_hoa_id,so_luong,loai,trang_thai FROM chi_tiet_sua_chua WHERE phieu_sua_id=? FOR UPDATE");$st->execute([$id]);$items=$st->fetchAll();
    $returned=0;
    if($p['trang_thai']!=='HUY'){
      foreach($items as $it){
        if($it['loai']==='PHU_TUNG'&&$it['hang_hoa_id']!==null&&$it['trang_thai']!=='HUY'){
          $this->reverseStock((int)$it['hang_hoa_id'],(float)$it['so_luong'],"PHIEU_SUA:$id:CT:{$it['chi_tiet_sua_id']}",'Hoàn phụ tùng do xóa phiếu sửa chữa '.$p['ma_phieu']);$returned++;
        }
      }
    }
    $this->db->prepare("DELETE FROM chi_tiet_sua_chua WHERE phieu_sua_id=?")->execute([$id]);
    $this->db->prepare("DELETE FROM phieu_sua_chua WHERE phieu_sua_id=?")->execute([$id]);
    $this->db->commit();
    return ['ma_phieu'=>(string)$p['ma_phieu'],'items'=>count($items),'returned'=>$returned];
  }catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}
 }
 public function deleteItem(int $itemId):void{$this->db->beginTransaction();try{$st=$this->db->prepare("SELECT ct.*,p.phieu_sua_id,(SELECT COUNT(*) FROM hoa_don h WHERE h.phieu_sua_id=p.phieu_sua_id AND h.trang_thai<>'HUY') invoice_count FROM chi_tiet_sua_chua ct JOIN phieu_sua_chua p ON p.phieu_sua_id=ct.phieu_sua_id WHERE ct.chi_tiet_sua_id=? FOR UPDATE");$st->execute([$itemId]);$item=$st->fetch();if(!$item)throw new RuntimeException('Không tìm thấy hạng mục.');if((int)$item['invoice_count']>0)throw new RuntimeException('Phiếu đã có hóa đơn, không thể xóa hạng mục.');$ps=$this->db->prepare('SELECT trang_thai FROM phieu_sua_chua WHERE phieu_sua_id=?');$ps->execute([$item['phieu_sua_id']]);if($ps->fetchColumn()==='HUY')throw new RuntimeException('Phiếu đã hủy, không thể xóa hạng mục.');$ref="PHIEU_SUA:{$item['phieu_sua_id']}:CT:$itemId";if($item['loai']==='PHU_TUNG'&&$item['hang_hoa_id'])$this->reverseStock((int)$item['hang_hoa_id'],(float)$item['so_luong'],$ref);$this->db->prepare('DELETE FROM chi_tiet_sua_chua WHERE chi_tiet_sua_id=?')->execute([$itemId]);$this->db->commit();}catch(Throwable $e){$this->db->rollBack();throw $e;}}
 private function reverseStock(int $productId,float $qty,string $originalRef,string $reason='Hoàn phụ tùng do xóa hạng mục sửa chữa'):void{$st=$this->db->prepare("SELECT COUNT(*) FROM phieu_kho WHERE loai_phieu='XUAT' AND tham_chieu=?");$st->execute([$originalRef]);if((int)$st->fetchColumn()===0)return;$st=$this->db->prepare("INSERT INTO phieu_kho(ma_phieu,loai_phieu,ly_do,tham_chieu) VALUES(LEFT(UUID(),30), 'NHAP', ?, ?)");$st->execute([$reason,"REV:$originalRef"]);$pid=(int)$this->db->lastInsertId();$this->db->prepare("UPDATE phieu_kho SET ma_phieu=? WHERE phieu_kho_id=?")->execute(['NK'.str_pad((string)$pid,5,'0',STR_PAD_LEFT),$pid]);$this->db->prepare("INSERT INTO chi_tiet_phieu_kho(phieu_kho_id,hang_hoa_id,so_luong,don_gia,ghi_chu) VALUES(?,?,?,?,?)")->execute([$pid,$productId,$qty,0,'Hoàn tự động khi xóa hạng mục']);$this->db->prepare("UPDATE hang_hoa SET ton_kho=ton_kho+? WHERE hang_hoa_id=?")->execute([$qty,$productId]);}
 public function products():array{return $this->db->query("SELECT h.hang_hoa_id,h.ma_hang,h.ten_hang,COALESCE(dv.ten_don_vi,'') don_vi,h.gia_ban AS don_gia,h.ton_kho,h.quan_ly_ton_kho FROM hang_hoa h LEFT JOIN don_vi_tinh dv ON dv.don_vi_id=h.don_vi_id WHERE h.trang_thai=1 ORDER BY h.ten_hang")->fetchAll();}
}
