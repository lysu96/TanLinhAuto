<?php
declare(strict_types=1);
final class Settings {
    public function __construct(private PDO $db) {}
    public function get(): array {
        try { $row=$this->db->query("SELECT * FROM cai_dat_gara WHERE cai_dat_id=1")->fetch(); return $row?:['cai_dat_id'=>1,'ten_gara'=>'TÂN LINH AUTO','dia_chi'=>'','so_dien_thoai'=>'','email'=>'','ma_so_thue'=>'','website'=>'','logo'=>'','ghi_chu'=>'']; }
        catch(Throwable $e){ return ['cai_dat_id'=>1,'ten_gara'=>'TÂN LINH AUTO','dia_chi'=>'','so_dien_thoai'=>'','email'=>'','ma_so_thue'=>'','website'=>'','logo'=>'','ghi_chu'=>'']; }
    }
    public function save(array $data, ?string $logo=null): void {
        $name=trim((string)($data['ten_gara']??'')); if($name==='') throw new RuntimeException('Tên gara không được để trống.');
        $old=$this->get(); $logo=$logo!==null ? $logo : ($old['logo']??null);
        $sql="INSERT INTO cai_dat_gara(cai_dat_id,ten_gara,dia_chi,so_dien_thoai,email,ma_so_thue,website,logo,ghi_chu) VALUES(1,?,?,?,?,?,?,?,?)
              ON DUPLICATE KEY UPDATE ten_gara=VALUES(ten_gara),dia_chi=VALUES(dia_chi),so_dien_thoai=VALUES(so_dien_thoai),email=VALUES(email),ma_so_thue=VALUES(ma_so_thue),website=VALUES(website),logo=VALUES(logo),ghi_chu=VALUES(ghi_chu)";
        $st=$this->db->prepare($sql); $st->execute([$name,trim((string)($data['dia_chi']??''))?:null,trim((string)($data['so_dien_thoai']??''))?:null,trim((string)($data['email']??''))?:null,trim((string)($data['ma_so_thue']??''))?:null,trim((string)($data['website']??''))?:null,$logo?:null,trim((string)($data['ghi_chu']??''))?:null]);
    }
}
