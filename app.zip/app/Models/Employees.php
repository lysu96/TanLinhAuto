<?php
declare(strict_types=1);
final class Employees {
    public function __construct(private PDO $db) {}
    public function list(string $q='', string $status=''): array {
        $where=[];$args=[];
        if($q!==''){ $where[]='(nv.ma_nv LIKE ? OR nv.ho_ten LIKE ? OR nv.so_dien_thoai LIKE ? OR tk.ten_dang_nhap LIKE ?)';$x="%$q%";array_push($args,$x,$x,$x,$x); }
        if($status!==''){ $where[]='nv.trang_thai=?';$args[]=(int)$status; }
        $sql="SELECT nv.*,tk.tai_khoan_id,tk.ten_dang_nhap,tk.trang_thai AS tai_khoan_trang_thai,tk.lan_dang_nhap_cuoi,vt.ma_vai_tro,vt.ten_vai_tro
              FROM nhan_vien nv LEFT JOIN tai_khoan tk ON tk.nhan_vien_id=nv.nhan_vien_id LEFT JOIN vai_tro vt ON vt.vai_tro_id=tk.vai_tro_id";
        if($where)$sql.=' WHERE '.implode(' AND ',$where);$sql.=' ORDER BY nv.nhan_vien_id DESC';$st=$this->db->prepare($sql);$st->execute($args);return $st->fetchAll();
    }
    public function roles(): array { return $this->db->query("SELECT * FROM vai_tro WHERE trang_thai=1 ORDER BY vai_tro_id")->fetchAll(); }
    public function detail(int $id): ?array { $st=$this->db->prepare("SELECT nv.*,tk.tai_khoan_id,tk.ten_dang_nhap,tk.trang_thai AS tai_khoan_trang_thai,tk.vai_tro_id,tk.lan_dang_nhap_cuoi,vt.ma_vai_tro,vt.ten_vai_tro FROM nhan_vien nv LEFT JOIN tai_khoan tk ON tk.nhan_vien_id=nv.nhan_vien_id LEFT JOIN vai_tro vt ON vt.vai_tro_id=tk.vai_tro_id WHERE nv.nhan_vien_id=?");$st->execute([$id]);return $st->fetch()?:null; }
    public function save(array $data,?int $id=null): int {
        $name=trim((string)($data['ho_ten']??''));$phone=trim((string)($data['so_dien_thoai']??''));$address=trim((string)($data['dia_chi']??''));$position=trim((string)($data['chuc_vu']??''));$active=!empty($data['trang_thai'])?1:0;
        if($name==='')throw new RuntimeException('Họ tên nhân viên không được để trống.');
        if($id){$st=$this->db->prepare("UPDATE nhan_vien SET ho_ten=?,so_dien_thoai=?,dia_chi=?,chuc_vu=?,trang_thai=? WHERE nhan_vien_id=?");$st->execute([$name,$phone?:null,$address?:null,$position?:null,$active,$id]);return $id;}
        $st=$this->db->prepare("INSERT INTO nhan_vien(ma_nv,ho_ten,so_dien_thoai,dia_chi,chuc_vu,trang_thai) VALUES(?,?,?,?,?,?)");$st->execute(['TMP-'.date('YmdHisv'),$name,$phone?:null,$address?:null,$position?:null,$active]);$new=(int)$this->db->lastInsertId();$ma='NV'.str_pad((string)$new,4,'0',STR_PAD_LEFT);$this->db->prepare("UPDATE nhan_vien SET ma_nv=? WHERE nhan_vien_id=?")->execute([$ma,$new]);return $new;
    }
    public function saveAccount(int $employeeId,array $data): void {
        $username=trim((string)($data['ten_dang_nhap']??''));$role=(int)($data['vai_tro_id']??0);$password=(string)($data['mat_khau']??'');$active=!empty($data['tai_khoan_trang_thai'])?1:0;
        if($username===''||$role<1)throw new RuntimeException('Tên đăng nhập và vai trò là bắt buộc.');
        $check=$this->db->prepare("SELECT tai_khoan_id FROM tai_khoan WHERE ten_dang_nhap=? AND nhan_vien_id<>?");$check->execute([$username,$employeeId]);if($check->fetch())throw new RuntimeException('Tên đăng nhập đã tồn tại.');
        $old=$this->detail($employeeId);$this->db->beginTransaction();try{
            if(!empty($old['tai_khoan_id'])){
                if($password!==''){$st=$this->db->prepare("UPDATE tai_khoan SET vai_tro_id=?,ten_dang_nhap=?,mat_khau=?,trang_thai=? WHERE tai_khoan_id=?");$st->execute([$role,$username,password_hash($password,PASSWORD_DEFAULT),$active,$old['tai_khoan_id']]);}
                else{$st=$this->db->prepare("UPDATE tai_khoan SET vai_tro_id=?,ten_dang_nhap=?,trang_thai=? WHERE tai_khoan_id=?");$st->execute([$role,$username,$active,$old['tai_khoan_id']]);}
            } else { if($password==='')throw new RuntimeException('Tài khoản mới phải có mật khẩu.');$st=$this->db->prepare("INSERT INTO tai_khoan(nhan_vien_id,vai_tro_id,ten_dang_nhap,mat_khau,trang_thai) VALUES(?,?,?,?,?)");$st->execute([$employeeId,$role,$username,password_hash($password,PASSWORD_DEFAULT),$active]); }
            $this->db->commit();
        }catch(Throwable $e){$this->db->rollBack();throw $e;}
    }
    public function toggle(int $id): void {$st=$this->db->prepare("UPDATE nhan_vien SET trang_thai=IF(trang_thai=1,0,1) WHERE nhan_vien_id=?");$st->execute([$id]);}
}
