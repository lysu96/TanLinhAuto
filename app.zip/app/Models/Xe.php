<?php
declare(strict_types=1);
final class Xe {
    public function __construct(private PDO $db) {}
    public function search(string $q,int $limit=20): array {
        $q=trim($q); $like="%{$q}%"; $limit=max(1,min($limit,100));
        $sql="SELECT x.xe_id,x.ma_xe,x.bien_so_hien_tai,x.loai_xe,x.nhan_hieu,x.model,k.ho_ten chu_hien_tai FROM xe x LEFT JOIN lich_su_so_huu_xe ls ON ls.xe_id=x.xe_id AND ls.la_chu_hien_tai=1 LEFT JOIN khach_hang k ON k.khach_hang_id=ls.khach_hang_id WHERE x.trang_thai=1 AND (x.bien_so_hien_tai LIKE ? OR x.ma_xe LIKE ? OR x.nhan_hieu LIKE ? OR k.ho_ten LIKE ? OR EXISTS(SELECT 1 FROM lich_su_bien_so lbs WHERE lbs.xe_id=x.xe_id AND lbs.bien_so LIKE ?)) ORDER BY x.xe_id DESC LIMIT $limit";
        $st=$this->db->prepare($sql); $st->execute([$like,$like,$like,$like,$like]); return $st->fetchAll();
    }
    public function list(string $q='',int $limit=50): array {
        $limit=max(1,min($limit,200)); $sql="SELECT x.*,k.khach_hang_id,k.ma_kh,k.ho_ten chu_hien_tai FROM xe x LEFT JOIN lich_su_so_huu_xe ls ON ls.xe_id=x.xe_id AND ls.la_chu_hien_tai=1 LEFT JOIN khach_hang k ON k.khach_hang_id=ls.khach_hang_id WHERE x.trang_thai=1"; $params=[];
        if($q!==''){ $like="%{$q}%"; $sql.=" AND (x.bien_so_hien_tai LIKE ? OR x.ma_xe LIKE ? OR x.nhan_hieu LIKE ? OR x.model LIKE ? OR k.ho_ten LIKE ? OR EXISTS(SELECT 1 FROM lich_su_bien_so lbs WHERE lbs.xe_id=x.xe_id AND lbs.bien_so LIKE ?))"; $params=[$like,$like,$like,$like,$like,$like]; }
        $sql.=" ORDER BY x.xe_id DESC LIMIT $limit"; $st=$this->db->prepare($sql); $st->execute($params); return $st->fetchAll();
    }
    public function create(array $d): int {
        $this->db->beginTransaction();
        try { $id=$this->insert($d, !empty($d['khach_hang_id'])?(int)$d['khach_hang_id']:null); $this->db->commit(); return $id; }
        catch(Throwable $e){ if($this->db->inTransaction()) $this->db->rollBack(); throw $e; }
    }
    /** Thêm xe (+ gán chủ nếu có $customerId), KHÔNG tự quản lý transaction. */
    public function insert(array $d, ?int $customerId=null): int {
        $plate=mb_strtoupper(trim((string)($d['bien_so_hien_tai']??'')),'UTF-8'); if($plate==='') throw new RuntimeException('Vui lòng nhập biển số xe.');
        $dup=$this->db->prepare("SELECT 1 FROM xe WHERE bien_so_hien_tai=? AND trang_thai=1 LIMIT 1"); $dup->execute([$plate]);
        if($dup->fetchColumn()) throw new RuntimeException('Biển số '.$plate.' đã tồn tại trong hệ thống.');
        $st=$this->db->prepare("INSERT INTO xe(ma_xe,bien_so_hien_tai,loai_xe,nhan_hieu,model,nam_san_xuat,so_khung,so_may,mau_xe,ghi_chu) VALUES(LEFT(UUID(),30),?,?,?,?,?,?,?,?,?)");
        $st->execute([$plate,trim((string)($d['loai_xe']??''))?:null,trim((string)($d['nhan_hieu']??''))?:null,trim((string)($d['model']??''))?:null,($d['nam_san_xuat']??'')!==''?(int)$d['nam_san_xuat']:null,trim((string)($d['so_khung']??''))?:null,trim((string)($d['so_may']??''))?:null,trim((string)($d['mau_xe']??''))?:null,trim((string)($d['ghi_chu']??''))?:null]);
        $id=(int)$this->db->lastInsertId(); $ma='XE'.str_pad((string)$id,4,'0',STR_PAD_LEFT); $this->db->prepare('UPDATE xe SET ma_xe=? WHERE xe_id=?')->execute([$ma,$id]);
        $this->db->prepare("INSERT INTO lich_su_bien_so(xe_id,bien_so,tu_ngay,la_bien_so_hien_tai) VALUES(?,?,CURDATE(),1)")->execute([$id,$plate]);
        if($customerId) $this->db->prepare("INSERT INTO lich_su_so_huu_xe(xe_id,khach_hang_id,tu_ngay,la_chu_hien_tai) VALUES(?,?,CURDATE(),1)")->execute([$id,$customerId]);
        return $id;
    }
    /** Gán chủ hiện tại cho xe chưa có chủ. KHÔNG tự quản lý transaction (người gọi tự bọc). */
    public function setOwner(int $xeId,int $customerId,?string $date=null,?string $note=null): void {
        $st=$this->db->prepare("SELECT xe_id FROM xe WHERE xe_id=? AND trang_thai=1 FOR UPDATE"); $st->execute([$xeId]);
        if(!$st->fetchColumn()) throw new RuntimeException('Không tìm thấy xe.');
        $st=$this->db->prepare("SELECT 1 FROM khach_hang WHERE khach_hang_id=? AND trang_thai=1"); $st->execute([$customerId]);
        if(!$st->fetchColumn()) throw new RuntimeException('Vui lòng chọn khách hàng hợp lệ.');
        $st=$this->db->prepare("SELECT 1 FROM lich_su_so_huu_xe WHERE xe_id=? AND la_chu_hien_tai=1 LIMIT 1"); $st->execute([$xeId]);
        if($st->fetchColumn()) throw new RuntimeException('Xe này đã có chủ hiện tại.');
        $date=trim((string)$date);
        if($date==='') $date=date('Y-m-d');
        $dt=DateTime::createFromFormat('Y-m-d',$date);
        if(!$dt||$dt->format('Y-m-d')!==$date) throw new RuntimeException('Ngày bắt đầu sở hữu không hợp lệ.');
        $this->db->prepare("INSERT INTO lich_su_so_huu_xe(xe_id,khach_hang_id,tu_ngay,la_chu_hien_tai,ghi_chu) VALUES(?,?,?,1,?)")
            ->execute([$xeId,$customerId,$date,($note!==null&&trim($note)!=='')?mb_substr(trim($note),0,255):null]);
    }
    /** Đổi chủ xe: đóng dòng chủ cũ, mở dòng chủ mới. KHÔNG tự quản lý transaction (người gọi tự bọc). Trả về id chủ cũ. */
    public function transferOwner(int $xeId,int $newCustomerId,?string $date=null,?string $note=null): int {
        $st=$this->db->prepare("SELECT xe_id FROM xe WHERE xe_id=? AND trang_thai=1 FOR UPDATE"); $st->execute([$xeId]);
        if(!$st->fetchColumn()) throw new RuntimeException('Không tìm thấy xe.');
        $st=$this->db->prepare("SELECT 1 FROM khach_hang WHERE khach_hang_id=? AND trang_thai=1"); $st->execute([$newCustomerId]);
        if(!$st->fetchColumn()) throw new RuntimeException('Vui lòng chọn chủ xe mới hợp lệ.');
        $st=$this->db->prepare("SELECT lich_su_id,khach_hang_id,tu_ngay FROM lich_su_so_huu_xe WHERE xe_id=? AND la_chu_hien_tai=1 LIMIT 1 FOR UPDATE"); $st->execute([$xeId]); $cur=$st->fetch();
        if(!$cur) throw new RuntimeException('Xe chưa có chủ hiện tại. Hãy dùng chức năng "Gán chủ xe".');
        if((int)$cur['khach_hang_id']===$newCustomerId) throw new RuntimeException('Chủ mới trùng với chủ hiện tại của xe.');
        $st=$this->db->prepare("SELECT COUNT(*) FROM phieu_sua_chua WHERE xe_id=? AND trang_thai NOT IN ('DA_GIAO_XE','HUY')"); $st->execute([$xeId]);
        if((int)$st->fetchColumn()>0) throw new RuntimeException('Xe đang có phiếu sửa chữa chưa giao xe/chưa hủy của chủ cũ. Hãy hoàn tất hoặc hủy phiếu trước khi đổi chủ.');
        $date=trim((string)$date); if($date==='') $date=date('Y-m-d');
        $dt=DateTime::createFromFormat('Y-m-d',$date);
        if(!$dt||$dt->format('Y-m-d')!==$date) throw new RuntimeException('Ngày đổi chủ không hợp lệ.');
        if($date>date('Y-m-d')) throw new RuntimeException('Ngày đổi chủ không được ở tương lai.');
        if($date<(string)$cur['tu_ngay']) throw new RuntimeException('Ngày đổi chủ không được trước ngày chủ hiện tại bắt đầu sở hữu ('.date('d/m/Y',strtotime((string)$cur['tu_ngay'])).').');
        $end=date('Y-m-d',strtotime($date.' -1 day')); if($end<(string)$cur['tu_ngay']) $end=(string)$cur['tu_ngay'];
        $this->db->prepare("UPDATE lich_su_so_huu_xe SET den_ngay=?,la_chu_hien_tai=0 WHERE lich_su_id=?")->execute([$end,$cur['lich_su_id']]);
        $this->db->prepare("INSERT INTO lich_su_so_huu_xe(xe_id,khach_hang_id,tu_ngay,la_chu_hien_tai,ghi_chu) VALUES(?,?,?,1,?)")
            ->execute([$xeId,$newCustomerId,$date,($note!==null&&trim($note)!=='')?mb_substr(trim($note),0,255):null]);
        return (int)$cur['khach_hang_id'];
    }
    public function detail(int $id): ?array {
        $st=$this->db->prepare("SELECT x.*,k.ho_ten chu_hien_tai,k.so_dien_thoai so_dien_thoai_chu FROM xe x LEFT JOIN lich_su_so_huu_xe ls ON ls.xe_id=x.xe_id AND ls.la_chu_hien_tai=1 LEFT JOIN khach_hang k ON k.khach_hang_id=ls.khach_hang_id WHERE x.xe_id=?"); $st->execute([$id]); $vehicle=$st->fetch(); if(!$vehicle)return null;
        $st=$this->db->prepare("SELECT ls.*,k.ma_kh,k.ho_ten,k.so_dien_thoai FROM lich_su_so_huu_xe ls JOIN khach_hang k ON k.khach_hang_id=ls.khach_hang_id WHERE ls.xe_id=? ORDER BY ls.tu_ngay DESC"); $st->execute([$id]); $owners=$st->fetchAll();
        $st=$this->db->prepare("SELECT * FROM lich_su_bien_so WHERE xe_id=? ORDER BY tu_ngay DESC"); $st->execute([$id]); $plates=$st->fetchAll();
        $st=$this->db->prepare("SELECT p.ma_phieu,p.ngay_tiep_nhan,p.trang_thai,p.khach_hang_id,k.ho_ten FROM phieu_sua_chua p JOIN khach_hang k ON k.khach_hang_id=p.khach_hang_id WHERE p.xe_id=? ORDER BY p.ngay_tiep_nhan DESC LIMIT 30"); $st->execute([$id]); $repairs=$st->fetchAll();
        return compact('vehicle','owners','plates','repairs');
    }
}
