<?php
declare(strict_types=1);
final class AuthModel {
    public function __construct(private PDO $db) {}
    public function countAccounts(): int { return (int)$this->db->query("SELECT COUNT(*) FROM tai_khoan")->fetchColumn(); }
    public function findUser(string $username): ?array {
        $sql="SELECT tk.tai_khoan_id,tk.nhan_vien_id,tk.vai_tro_id,tk.ten_dang_nhap,tk.mat_khau,nv.ho_ten,nv.ma_nv,vt.ma_vai_tro,vt.ten_vai_tro
              FROM tai_khoan tk JOIN nhan_vien nv ON nv.nhan_vien_id=tk.nhan_vien_id JOIN vai_tro vt ON vt.vai_tro_id=tk.vai_tro_id
              WHERE tk.ten_dang_nhap=? AND tk.trang_thai=1 AND nv.trang_thai=1 AND vt.trang_thai=1 LIMIT 1";
        $st=$this->db->prepare($sql);$st->execute([$username]);return $st->fetch()?:null;
    }
    public function markLogin(int $id): void { $st=$this->db->prepare("UPDATE tai_khoan SET lan_dang_nhap_cuoi=NOW() WHERE tai_khoan_id=?");$st->execute([$id]); }
    public function createFirstAdmin(string $name,string $username,string $password): void {
        if($this->countAccounts()>0) throw new RuntimeException('Hệ thống đã có tài khoản.');
        $this->db->beginTransaction();
        try{
            $st=$this->db->prepare("INSERT INTO nhan_vien(ma_nv,ho_ten,chuc_vu,trang_thai) VALUES(?,?,?,1)");$st->execute(['TMP-'.date('YmdHis'),$name,'Quản trị hệ thống']);$nv=(int)$this->db->lastInsertId();
            $ma='NV'.str_pad((string)$nv,4,'0',STR_PAD_LEFT);$this->db->prepare("UPDATE nhan_vien SET ma_nv=? WHERE nhan_vien_id=?")->execute([$ma,$nv]);
            $hash=password_hash($password,PASSWORD_DEFAULT);$st=$this->db->prepare("INSERT INTO tai_khoan(nhan_vien_id,vai_tro_id,ten_dang_nhap,mat_khau,trang_thai) VALUES(?,1,?,?,1)");$st->execute([$nv,$username,$hash]);
            $this->db->commit();
        }catch(Throwable $e){$this->db->rollBack();throw $e;}
    }
}
