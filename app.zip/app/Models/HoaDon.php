<?php
declare(strict_types=1);
final class HoaDon {
    public function __construct(private PDO $db) {}
    public function list(string $q='', string $status=''): array {
        $sql="SELECT h.*,k.ma_kh,k.ho_ten,x.bien_so_hien_tai,x.ma_xe,
          (h.tong_tien-h.giam_gia) AS thuc_thu, h.con_no AS con_no_hien_tai
          FROM hoa_don h JOIN khach_hang k ON k.khach_hang_id=h.khach_hang_id JOIN xe x ON x.xe_id=h.xe_id WHERE 1=1";
        $p=[];
        if($q!==''){ $l="%{$q}%"; $sql.=" AND (h.so_hoa_don LIKE ? OR k.ho_ten LIKE ? OR k.ma_kh LIKE ? OR x.bien_so_hien_tai LIKE ? OR x.ma_xe LIKE ?)"; $p=[$l,$l,$l,$l,$l]; }
        if($status!==''){ $sql.=" AND h.trang_thai=?"; $p[]=$status; }
        $sql.=" ORDER BY h.hoa_don_id DESC LIMIT 150";
        $st=$this->db->prepare($sql);$st->execute($p);return $st->fetchAll();
    }
    public function detail(int $id): ?array {
        $st=$this->db->prepare("SELECT h.*,k.ma_kh,k.ho_ten,k.so_dien_thoai,k.dia_chi,x.ma_xe,x.bien_so_hien_tai,x.nhan_hieu,x.model,p.ma_phieu FROM hoa_don h JOIN khach_hang k ON k.khach_hang_id=h.khach_hang_id JOIN xe x ON x.xe_id=h.xe_id LEFT JOIN phieu_sua_chua p ON p.phieu_sua_id=h.phieu_sua_id WHERE h.hoa_don_id=?");$st->execute([$id]);$h=$st->fetch();if(!$h)return null;
        $st=$this->db->prepare("SELECT ct.*,h.ma_hang FROM chi_tiet_hoa_don ct LEFT JOIN hang_hoa h ON h.hang_hoa_id=ct.hang_hoa_id WHERE ct.hoa_don_id=? ORDER BY ct.chi_tiet_hd_id");$st->execute([$id]);$items=$st->fetchAll();
        $st=$this->db->prepare("SELECT t.*,pt.ten_phuong_thuc FROM thanh_toan t JOIN phuong_thuc_thanh_toan pt ON pt.phuong_thuc_id=t.phuong_thuc_id WHERE t.hoa_don_id=? ORDER BY t.thanh_toan_id DESC");$st->execute([$id]);$payments=$st->fetchAll();
        $credit=$this->creditBalance((int)$h['khach_hang_id']);
        $st=$this->db->prepare("SELECT s.*,pt.ten_phuong_thuc FROM so_du_khach_hang s LEFT JOIN phuong_thuc_thanh_toan pt ON pt.phuong_thuc_id=s.phuong_thuc_id WHERE s.hoa_don_id=? ORDER BY s.so_du_id DESC");$st->execute([$id]);$credit_rows=$st->fetchAll();
        return compact('h','items','payments','credit','credit_rows');
    }
    public function repairOptions(): array {
        return $this->db->query("SELECT p.phieu_sua_id,p.ma_phieu,p.khach_hang_id,p.xe_id,k.ho_ten,x.bien_so_hien_tai,
          COALESCE((SELECT SUM(ct.thanh_tien) FROM chi_tiet_sua_chua ct WHERE ct.phieu_sua_id=p.phieu_sua_id AND ct.trang_thai<>'HUY'),0) AS tong_sua
          FROM phieu_sua_chua p JOIN khach_hang k ON k.khach_hang_id=p.khach_hang_id JOIN xe x ON x.xe_id=p.xe_id
          WHERE p.trang_thai NOT IN ('HUY') AND NOT EXISTS (SELECT 1 FROM hoa_don h WHERE h.phieu_sua_id=p.phieu_sua_id AND h.trang_thai<>'HUY') ORDER BY p.phieu_sua_id DESC LIMIT 200")->fetchAll();
    }
    private function oldDebt(int $customerId): float {
        $st=$this->db->prepare("SELECT COALESCE(SUM(con_no),0) FROM hoa_don WHERE khach_hang_id=? AND trang_thai<>'HUY'");$st->execute([$customerId]);$d=(float)$st->fetchColumn();
        $st=$this->db->prepare("SELECT COALESCE(SUM(CASE WHEN loai='TANG_NO' THEN so_tien ELSE -so_tien END),0) FROM cong_no_dieu_chinh WHERE khach_hang_id=?");$st->execute([$customerId]);return max(0,$d+(float)$st->fetchColumn());
    }
    public function createFromRepair(int $repairId, float $discount=0, string $note=''): int {
        $st=$this->db->prepare("SELECT p.*,k.ho_ten FROM phieu_sua_chua p JOIN khach_hang k ON k.khach_hang_id=p.khach_hang_id WHERE p.phieu_sua_id=?");$st->execute([$repairId]);$p=$st->fetch();if(!$p)throw new RuntimeException('Không tìm thấy phiếu sửa chữa.');
        $st=$this->db->prepare("SELECT COUNT(*) FROM hoa_don WHERE phieu_sua_id=? AND trang_thai<>'HUY'");$st->execute([$repairId]);if((int)$st->fetchColumn()>0)throw new RuntimeException('Phiếu sửa chữa này đã có hóa đơn.');
        $st=$this->db->prepare("SELECT * FROM chi_tiet_sua_chua WHERE phieu_sua_id=? AND trang_thai<>'HUY' ORDER BY chi_tiet_sua_id");$st->execute([$repairId]);$items=$st->fetchAll();if(!$items)throw new RuntimeException('Phiếu sửa chữa chưa có hạng mục.');
        $old=$this->oldDebt((int)$p['khach_hang_id']);$this->db->beginTransaction();
        try {
            $st=$this->db->prepare("INSERT INTO hoa_don(so_hoa_don,khach_hang_id,xe_id,phieu_sua_id,giam_gia,no_cu,trang_thai,ghi_chu) VALUES(LEFT(UUID(),30),?,?,?,?,?,?,?)");
            $st->execute([$p['khach_hang_id'],$p['xe_id'],$repairId,max(0,$discount),$old,'DA_XUAT',$note?:null]);$id=(int)$this->db->lastInsertId();
            $this->db->prepare("UPDATE hoa_don SET so_hoa_don=? WHERE hoa_don_id=?")->execute(['HD'.str_pad((string)$id,5,'0',STR_PAD_LEFT),$id]);
            $ins=$this->db->prepare("INSERT INTO chi_tiet_hoa_don(hoa_don_id,hang_hoa_id,ten_hang_snapshot,don_vi_snapshot,loai,so_luong,don_gia,giam_gia,ghi_chu) VALUES(?,?,?,?,?,?,?,?,?)");
            foreach($items as $i){$ins->execute([$id,$i['hang_hoa_id'],$i['ten_hang_snapshot'],$i['don_vi_snapshot'],$i['loai'],$i['so_luong'],$i['don_gia'],$i['giam_gia'],$i['ghi_chu']]);}
            $this->db->commit();return $id;
        }catch(Throwable $e){$this->db->rollBack();throw $e;}
    }
    private static bool $creditReady=false;
    private static int $creditMethod=0;
    /** Tạo bảng số dư + phương thức "Trừ từ số dư" nếu chưa có (an toàn khi chạy nhiều lần). Phải gọi TRƯỚC beginTransaction. */
    public function ensureCreditSchema(): void {
        if(self::$creditReady) return;
        $this->db->exec("CREATE TABLE IF NOT EXISTS so_du_khach_hang (
          so_du_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
          khach_hang_id INT UNSIGNED NOT NULL,
          ngay_phat_sinh DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          loai ENUM('THU_THUA','TRU_HOA_DON','HOAN_TIEN') NOT NULL,
          so_tien DECIMAL(15,2) NOT NULL,
          hoa_don_id INT UNSIGNED NULL,
          phuong_thuc_id SMALLINT UNSIGNED NULL,
          ghi_chu VARCHAR(255) NULL,
          nguoi_tao_id INT UNSIGNED NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (so_du_id),
          KEY idx_sd_kh (khach_hang_id, ngay_phat_sinh),
          KEY idx_sd_hd (hoa_don_id),
          CONSTRAINT fk_sd_kh FOREIGN KEY (khach_hang_id) REFERENCES khach_hang(khach_hang_id),
          CONSTRAINT fk_sd_hd FOREIGN KEY (hoa_don_id) REFERENCES hoa_don(hoa_don_id),
          CONSTRAINT fk_sd_pt FOREIGN KEY (phuong_thuc_id) REFERENCES phuong_thuc_thanh_toan(phuong_thuc_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $st=$this->db->prepare("SELECT phuong_thuc_id FROM phuong_thuc_thanh_toan WHERE ma_phuong_thuc='SO_DU' LIMIT 1"); $st->execute(); $id=(int)$st->fetchColumn();
        if(!$id){ $this->db->prepare("INSERT INTO phuong_thuc_thanh_toan(ma_phuong_thuc,ten_phuong_thuc,trang_thai) VALUES('SO_DU','Trừ từ số dư khách',1)")->execute(); $id=(int)$this->db->lastInsertId(); }
        self::$creditMethod=$id; self::$creditReady=true;
    }
    private function actorId(): ?int { $v=Auth::user()['nhan_vien_id']??null; return $v?(int)$v:null; }
    private function validMethod(int $method): void {
        $this->ensureCreditSchema();
        if($method===self::$creditMethod) throw new RuntimeException('Phương thức thanh toán không hợp lệ.');
        $st=$this->db->prepare("SELECT 1 FROM phuong_thuc_thanh_toan WHERE phuong_thuc_id=? AND trang_thai=1"); $st->execute([$method]);
        if(!$st->fetchColumn()) throw new RuntimeException('Vui lòng chọn phương thức thanh toán.');
    }
    private function lockCustomer(int $customerId): void {
        $st=$this->db->prepare("SELECT 1 FROM khach_hang WHERE khach_hang_id=? FOR UPDATE"); $st->execute([$customerId]);
        if(!$st->fetchColumn()) throw new RuntimeException('Không tìm thấy khách hàng.');
    }
    /** Số dư của khách = tiền khách trả thừa mà gara đang giữ (gara nợ khách). */
    public function creditBalance(int $customerId): float {
        $this->ensureCreditSchema();
        $st=$this->db->prepare("SELECT COALESCE(SUM(CASE WHEN loai='THU_THUA' THEN so_tien ELSE -so_tien END),0) FROM so_du_khach_hang WHERE khach_hang_id=?"); $st->execute([$customerId]);
        return round((float)$st->fetchColumn(),2);
    }
    public function creditLedger(int $customerId,int $limit=30): array {
        $this->ensureCreditSchema(); $limit=max(1,min($limit,200));
        $st=$this->db->prepare("SELECT s.*,h.so_hoa_don,pt.ten_phuong_thuc FROM so_du_khach_hang s LEFT JOIN hoa_don h ON h.hoa_don_id=s.hoa_don_id LEFT JOIN phuong_thuc_thanh_toan pt ON pt.phuong_thuc_id=s.phuong_thuc_id WHERE s.khach_hang_id=? ORDER BY s.so_du_id DESC LIMIT $limit");
        $st->execute([$customerId]); return $st->fetchAll();
    }
    public function creditCustomers(string $q=''): array {
        $this->ensureCreditSchema();
        $sql="SELECT k.khach_hang_id,k.ma_kh,k.ho_ten,k.so_dien_thoai,SUM(CASE WHEN s.loai='THU_THUA' THEN s.so_tien ELSE -s.so_tien END) so_du FROM khach_hang k JOIN so_du_khach_hang s ON s.khach_hang_id=k.khach_hang_id WHERE k.trang_thai=1"; $p=[];
        if($q!==''){ $l="%{$q}%"; $sql.=" AND (k.ho_ten LIKE ? OR k.ma_kh LIKE ? OR k.so_dien_thoai LIKE ?)"; $p=[$l,$l,$l]; }
        $sql.=" GROUP BY k.khach_hang_id HAVING so_du>0.004 ORDER BY so_du DESC LIMIT 200";
        $st=$this->db->prepare($sql); $st->execute($p); return $st->fetchAll();
    }
    /** Thu tiền. Nếu khách đưa nhiều hơn số còn nợ: phần đủ trừ vào hóa đơn, phần thừa ghi vào số dư của khách. Trả về ['applied'=>..,'excess'=>..]. */
    public function pay(int $invoiceId,float $amount,int $method,string $tx='',string $note=''): array {
        $amount=round($amount,2);
        if($amount<=0)throw new RuntimeException('Số tiền thanh toán phải lớn hơn 0.');
        $this->validMethod($method);
        $this->db->beginTransaction();
        try{
            $st=$this->db->prepare("SELECT khach_hang_id,so_hoa_don,con_no,trang_thai FROM hoa_don WHERE hoa_don_id=? FOR UPDATE");$st->execute([$invoiceId]);$h=$st->fetch();
            if(!$h)throw new RuntimeException('Không tìm thấy hóa đơn.');
            if($h['trang_thai']==='HUY')throw new RuntimeException('Hóa đơn đã hủy, không thể thu tiền.');
            $due=round((float)$h['con_no'],2);
            if($due<=0)throw new RuntimeException('Hóa đơn đã thanh toán đủ.');
            $applied=min($amount,$due); $excess=round($amount-$applied,2);
            $st=$this->db->prepare("INSERT INTO thanh_toan(hoa_don_id,khach_hang_id,phuong_thuc_id,so_tien,ma_giao_dich,ghi_chu) VALUES(?,?,?,?,?,?)");
            $st->execute([$invoiceId,$h['khach_hang_id'],$method,$applied,$tx?:null,$note?:null]);
            if($excess>0){
                $this->lockCustomer((int)$h['khach_hang_id']);
                $this->db->prepare("INSERT INTO so_du_khach_hang(khach_hang_id,loai,so_tien,hoa_don_id,phuong_thuc_id,ghi_chu,nguoi_tao_id) VALUES(?,?,?,?,?,?,?)")
                    ->execute([$h['khach_hang_id'],'THU_THUA',$excess,$invoiceId,$method,'Khách trả thừa khi thanh toán '.$h['so_hoa_don'],$this->actorId()]);
            }
            $this->db->commit(); return ['applied'=>$applied,'excess'=>$excess];
        }catch(Throwable $e){ if($this->db->inTransaction())$this->db->rollBack(); throw $e; }
    }
    /** Trừ số dư của khách vào một hóa đơn còn nợ. */
    public function applyCredit(int $invoiceId,float $amount): float {
        $amount=round($amount,2);
        if($amount<=0)throw new RuntimeException('Số tiền trừ phải lớn hơn 0.');
        $this->ensureCreditSchema();
        $this->db->beginTransaction();
        try{
            $st=$this->db->prepare("SELECT khach_hang_id,so_hoa_don,con_no,trang_thai FROM hoa_don WHERE hoa_don_id=? FOR UPDATE");$st->execute([$invoiceId]);$h=$st->fetch();
            if(!$h)throw new RuntimeException('Không tìm thấy hóa đơn.');
            if($h['trang_thai']==='HUY')throw new RuntimeException('Hóa đơn đã hủy.');
            $due=round((float)$h['con_no'],2);
            if($due<=0)throw new RuntimeException('Hóa đơn đã thanh toán đủ.');
            $cid=(int)$h['khach_hang_id']; $this->lockCustomer($cid);
            $bal=$this->creditBalance($cid);
            if($amount>$bal+0.004)throw new RuntimeException('Số tiền vượt quá số dư của khách ('.number_format($bal,0,',','.').' đ).');
            if($amount>$due+0.004)throw new RuntimeException('Số tiền vượt quá số còn nợ của hóa đơn ('.number_format($due,0,',','.').' đ).');
            $this->db->prepare("INSERT INTO thanh_toan(hoa_don_id,khach_hang_id,phuong_thuc_id,so_tien,ghi_chu) VALUES(?,?,?,?,?)")->execute([$invoiceId,$cid,self::$creditMethod,$amount,'Trừ từ số dư khách']);
            $this->db->prepare("INSERT INTO so_du_khach_hang(khach_hang_id,loai,so_tien,hoa_don_id,ghi_chu,nguoi_tao_id) VALUES(?,?,?,?,?,?)")->execute([$cid,'TRU_HOA_DON',$amount,$invoiceId,'Trừ số dư vào hóa đơn '.$h['so_hoa_don'],$this->actorId()]);
            $this->db->commit(); return $amount;
        }catch(Throwable $e){ if($this->db->inTransaction())$this->db->rollBack(); throw $e; }
    }
    /** Gara hoàn lại tiền (tiền mặt/chuyển khoản) cho khách từ số dư. */
    public function refundCredit(int $customerId,float $amount,int $method,string $note=''): float {
        $amount=round($amount,2);
        if($amount<=0)throw new RuntimeException('Số tiền hoàn phải lớn hơn 0.');
        $this->validMethod($method);
        $this->db->beginTransaction();
        try{
            $this->lockCustomer($customerId);
            $bal=$this->creditBalance($customerId);
            if($amount>$bal+0.004)throw new RuntimeException('Số tiền hoàn vượt quá số dư của khách ('.number_format($bal,0,',','.').' đ).');
            $this->db->prepare("INSERT INTO so_du_khach_hang(khach_hang_id,loai,so_tien,phuong_thuc_id,ghi_chu,nguoi_tao_id) VALUES(?,?,?,?,?,?)")->execute([$customerId,'HOAN_TIEN',$amount,$method,$note!==''?mb_substr($note,0,255):'Hoàn tiền cho khách',$this->actorId()]);
            $this->db->commit(); return $amount;
        }catch(Throwable $e){ if($this->db->inTransaction())$this->db->rollBack(); throw $e; }
    }
    /** Xóa vĩnh viễn hóa đơn. Số tiền đã thu (kể cả phần trừ từ số dư) được chuyển thành số dư của khách để không mất dấu tiền. */
    public function deleteInvoice(int $invoiceId): array {
        $this->ensureCreditSchema();
        $this->db->beginTransaction();
        try{
            $st=$this->db->prepare("SELECT hoa_don_id,so_hoa_don,khach_hang_id,tong_tien,giam_gia FROM hoa_don WHERE hoa_don_id=? FOR UPDATE");$st->execute([$invoiceId]);$h=$st->fetch();
            if(!$h)throw new RuntimeException('Không tìm thấy hóa đơn (có thể đã bị xóa).');
            $cid=(int)$h['khach_hang_id']; $this->lockCustomer($cid);
            $st=$this->db->prepare("SELECT ho_ten FROM khach_hang WHERE khach_hang_id=?");$st->execute([$cid]);$name=(string)$st->fetchColumn();
            $st=$this->db->prepare("SELECT COALESCE(SUM(so_tien),0) FROM thanh_toan WHERE hoa_don_id=?");$st->execute([$invoiceId]);$paid=round((float)$st->fetchColumn(),2);
            if($paid>0.004){
                $this->db->prepare("INSERT INTO so_du_khach_hang(khach_hang_id,loai,so_tien,ghi_chu,nguoi_tao_id) VALUES(?,?,?,?,?)")
                    ->execute([$cid,'THU_THUA',$paid,'Hoàn lại tiền đã thu từ hóa đơn bị xóa '.$h['so_hoa_don'],$this->actorId()]);
            }
            $this->db->prepare("UPDATE so_du_khach_hang SET hoa_don_id=NULL WHERE hoa_don_id=?")->execute([$invoiceId]);
            $this->db->prepare("DELETE FROM thanh_toan WHERE hoa_don_id=?")->execute([$invoiceId]);
            $this->db->prepare("DELETE FROM chi_tiet_hoa_don WHERE hoa_don_id=?")->execute([$invoiceId]);
            $this->db->prepare("DELETE FROM hoa_don WHERE hoa_don_id=?")->execute([$invoiceId]);
            $this->db->commit();
            return ['so_hoa_don'=>(string)$h['so_hoa_don'],'ho_ten'=>$name,'khach_hang_id'=>$cid,'tong'=>round((float)$h['tong_tien']-(float)$h['giam_gia'],2),'paid'=>$paid];
        }catch(Throwable $e){ if($this->db->inTransaction())$this->db->rollBack(); throw $e; }
    }
    public function paymentMethods(): array{return $this->db->query("SELECT phuong_thuc_id,ma_phuong_thuc,ten_phuong_thuc FROM phuong_thuc_thanh_toan WHERE trang_thai=1 AND ma_phuong_thuc<>'SO_DU' ORDER BY phuong_thuc_id")->fetchAll();}
    public function debtCustomers(string $q=''): array {
        $sql="SELECT k.khach_hang_id,k.ma_kh,k.ho_ten,k.so_dien_thoai,
          GREATEST(0,COALESCE((SELECT SUM(h.con_no) FROM hoa_don h WHERE h.khach_hang_id=k.khach_hang_id AND h.trang_thai<>'HUY'),0)+COALESCE((SELECT SUM(CASE WHEN c.loai='TANG_NO' THEN c.so_tien ELSE -c.so_tien END) FROM cong_no_dieu_chinh c WHERE c.khach_hang_id=k.khach_hang_id),0)) AS tong_con_no
          FROM khach_hang k WHERE k.trang_thai=1";$p=[];if($q!==''){$l="%{$q}%";$sql.=" AND (k.ho_ten LIKE ? OR k.ma_kh LIKE ? OR k.so_dien_thoai LIKE ?)";$p=[$l,$l,$l];}$sql.=" HAVING tong_con_no>0 ORDER BY tong_con_no DESC LIMIT 200";$st=$this->db->prepare($sql);$st->execute($p);return $st->fetchAll();
    }
}
