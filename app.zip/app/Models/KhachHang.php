<?php
declare(strict_types=1);
final class KhachHang {
    public function __construct(private PDO $db) {}
    public function search(string $q, int $limit=20): array {
        $q=trim($q); $like="%{$q}%";
        $limit=max(1,min($limit,100));
        $st=$this->db->prepare("SELECT khach_hang_id,ma_kh,ho_ten,so_dien_thoai,dia_chi,trang_thai FROM khach_hang WHERE trang_thai=1 AND (ho_ten LIKE ? OR so_dien_thoai LIKE ? OR ma_kh LIKE ?) ORDER BY ho_ten LIMIT $limit");
        $st->execute([$like,$like,$like]); return $st->fetchAll();
    }
    public function list(string $q='', int $limit=50): array {
        $limit=max(1,min($limit,200)); $sql="SELECT k.*, COUNT(DISTINCT CASE WHEN ls.la_chu_hien_tai=1 THEN ls.xe_id END) so_xe, COALESCE((SELECT SUM(h.con_no) FROM hoa_don h WHERE h.khach_hang_id=k.khach_hang_id AND h.trang_thai<>'HUY'),0) cong_no FROM khach_hang k LEFT JOIN lich_su_so_huu_xe ls ON ls.khach_hang_id=k.khach_hang_id WHERE k.trang_thai=1";
        $params=[];
        if($q!==''){ $like="%{$q}%"; $sql.=" AND (k.ho_ten LIKE ? OR k.so_dien_thoai LIKE ? OR k.ma_kh LIKE ?)"; $params=[$like,$like,$like]; }
        $sql.=" GROUP BY k.khach_hang_id ORDER BY k.khach_hang_id DESC LIMIT $limit";
        $st=$this->db->prepare($sql); $st->execute($params); return $st->fetchAll();
    }
    public function all(): array {
        return $this->db->query("SELECT khach_hang_id,ma_kh,ho_ten,so_dien_thoai FROM khach_hang WHERE trang_thai=1 ORDER BY ho_ten")->fetchAll();
    }
    public function create(array $d): int {
        $this->db->beginTransaction();
        try { $id=$this->insert($d); $this->db->commit(); return $id; }
        catch(Throwable $e){ if($this->db->inTransaction()) $this->db->rollBack(); throw $e; }
    }
    public function exists(int $id): bool {
        $st=$this->db->prepare('SELECT 1 FROM khach_hang WHERE khach_hang_id=? AND trang_thai=1'); $st->execute([$id]); return (bool)$st->fetchColumn();
    }
    /** Thêm khách hàng, KHÔNG tự quản lý transaction (người gọi tự bọc). */
    public function insert(array $d): int {
        $name=trim((string)($d['ho_ten']??'')); if($name==='') throw new RuntimeException('Vui lòng nhập họ tên khách hàng.');
        {
            $st=$this->db->prepare("INSERT INTO khach_hang(ma_kh,ho_ten,so_dien_thoai,dia_chi,ghi_chu) VALUES(LEFT(UUID(),30),?,?,?,?)");
            $st->execute([$name,trim((string)($d['so_dien_thoai']??''))?:null,trim((string)($d['dia_chi']??''))?:null,trim((string)($d['ghi_chu']??''))?:null]);
            $id=(int)$this->db->lastInsertId(); $ma='KH'.str_pad((string)$id,4,'0',STR_PAD_LEFT);
            $this->db->prepare('UPDATE khach_hang SET ma_kh=? WHERE khach_hang_id=?')->execute([$ma,$id]);
            return $id;
        }
    }
    public function detail(int $id): ?array {
        $st=$this->db->prepare('SELECT * FROM khach_hang WHERE khach_hang_id=?'); $st->execute([$id]); $customer=$st->fetch(); if(!$customer)return null;
        $st=$this->db->prepare("SELECT x.*, ls.tu_ngay,ls.den_ngay,ls.la_chu_hien_tai FROM lich_su_so_huu_xe ls JOIN xe x ON x.xe_id=ls.xe_id WHERE ls.khach_hang_id=? ORDER BY ls.la_chu_hien_tai DESC, ls.tu_ngay DESC"); $st->execute([$id]); $vehicles=$st->fetchAll();
        $st=$this->db->prepare("SELECT p.phieu_sua_id,p.ma_phieu,p.ngay_tiep_nhan,p.trang_thai,x.bien_so_hien_tai FROM phieu_sua_chua p JOIN xe x ON x.xe_id=p.xe_id WHERE p.khach_hang_id=? ORDER BY p.ngay_tiep_nhan DESC LIMIT 20"); $st->execute([$id]); $repairs=$st->fetchAll();
        $st=$this->db->prepare("SELECT h.hoa_don_id,h.so_hoa_don,h.ngay_lap,h.tong_tien,h.giam_gia,h.da_thanh_toan,h.con_no,h.trang_thai,x.bien_so_hien_tai,p.ma_phieu FROM hoa_don h JOIN xe x ON x.xe_id=h.xe_id LEFT JOIN phieu_sua_chua p ON p.phieu_sua_id=h.phieu_sua_id WHERE h.khach_hang_id=? ORDER BY h.hoa_don_id DESC LIMIT 50"); $st->execute([$id]); $invoices=$st->fetchAll();
        $st=$this->db->prepare("SELECT COUNT(*) so_hd,COALESCE(SUM(tong_tien-giam_gia),0) tong,COALESCE(SUM(da_thanh_toan),0) da_tra,COALESCE(SUM(con_no),0) con_no FROM hoa_don WHERE khach_hang_id=? AND trang_thai<>'HUY'"); $st->execute([$id]); $invoiceTotals=$st->fetch();
        return compact('customer','vehicles','repairs','invoices','invoiceTotals');
    }
}
