<?php
declare(strict_types=1);
final class HangHoa {
    public function __construct(private PDO $db) {}
    public function list(string $q='', string $stock='', bool $inactive=false): array {
        $sql="SELECT h.*,nh.ten_nhom,dv.ten_don_vi FROM hang_hoa h LEFT JOIN nhom_hang nh ON nh.nhom_hang_id=h.nhom_hang_id LEFT JOIN don_vi_tinh dv ON dv.don_vi_id=h.don_vi_id WHERE ".($inactive?'1=1':'h.trang_thai=1'); $p=[];
        if($q!==''){ $like="%$q%"; $sql.=" AND (h.ma_hang LIKE ? OR h.ten_hang LIKE ? OR nh.ten_nhom LIKE ?)"; $p=[$like,$like,$like]; }
        if($stock==='low') $sql.=" AND h.quan_ly_ton_kho=1 AND h.ton_kho<=h.muc_ton_toi_thieu";
        if($stock==='out') $sql.=" AND h.quan_ly_ton_kho=1 AND h.ton_kho<=0";
        $sql.=" ORDER BY (h.quan_ly_ton_kho=1 AND h.ton_kho<=h.muc_ton_toi_thieu) DESC,h.ten_hang LIMIT 300";
        $st=$this->db->prepare($sql); $st->execute($p); return $st->fetchAll();
    }
    public function all(): array { return $this->db->query("SELECT hang_hoa_id,ma_hang,ten_hang,ton_kho FROM hang_hoa WHERE trang_thai=1 ORDER BY ten_hang")->fetchAll(); }
    public function groups(): array { return $this->db->query("SELECT nhom_hang_id,ten_nhom FROM nhom_hang WHERE trang_thai=1 ORDER BY ten_nhom")->fetchAll(); }
    public function units(): array { return $this->db->query("SELECT don_vi_id,ten_don_vi FROM don_vi_tinh WHERE trang_thai=1 ORDER BY ten_don_vi")->fetchAll(); }
    public function create(array $d): int {
        $ma=trim((string)($d['ma_hang']??'')); $ten=trim((string)($d['ten_hang']??''));
        if($ma===''||$ten==='') throw new RuntimeException('Mã hàng và tên hàng là bắt buộc.');
        $this->assertCodeFree($ma,0);
        $st=$this->db->prepare("INSERT INTO hang_hoa(ma_hang,ten_hang,nhom_hang_id,don_vi_id,gia_nhap,gia_ban,ton_kho,muc_ton_toi_thieu,quan_ly_ton_kho,mo_ta) VALUES(?,?,?,?,?,?,?,?,?,?)");
        $st->execute([$ma,$ten,($d['nhom_hang_id']??'')!==''?(int)$d['nhom_hang_id']:null,($d['don_vi_id']??'')!==''?(int)$d['don_vi_id']:null,(float)($d['gia_nhap']??0),(float)($d['gia_ban']??0),(float)($d['ton_kho']??0),(float)($d['muc_ton_toi_thieu']??0),!empty($d['quan_ly_ton_kho'])?1:0,trim((string)($d['mo_ta']??''))?:null]);
        return (int)$this->db->lastInsertId();
    }
    private function assertCodeFree(string $ma,int $exceptId): void {
        if(mb_strlen($ma)>30) throw new RuntimeException('Mã hàng tối đa 30 ký tự.');
        $st=$this->db->prepare("SELECT 1 FROM hang_hoa WHERE ma_hang=? AND hang_hoa_id<>? LIMIT 1"); $st->execute([$ma,$exceptId]);
        if($st->fetchColumn()) throw new RuntimeException('Mã hàng "'.$ma.'" đã tồn tại, hãy dùng mã khác.');
    }
    public function find(int $id): ?array { $st=$this->db->prepare("SELECT * FROM hang_hoa WHERE hang_hoa_id=?"); $st->execute([$id]); $r=$st->fetch(); return $r?:null; }
    /** Sửa thông tin hàng hóa. KHÔNG sửa tồn kho ở đây (dùng "Kiểm kê / điều chỉnh tồn" để có phiếu kho ghi vết). */
    public function update(int $id,array $d): void {
        $ma=trim((string)($d['ma_hang']??'')); $ten=trim((string)($d['ten_hang']??''));
        if($ma===''||$ten==='') throw new RuntimeException('Mã hàng và tên hàng là bắt buộc.');
        if(mb_strlen($ten)>255) throw new RuntimeException('Tên hàng tối đa 255 ký tự.');
        $nhap=(float)($d['gia_nhap']??0); $ban=(float)($d['gia_ban']??0); $min=(float)($d['muc_ton_toi_thieu']??0);
        if($nhap<0||$ban<0||$min<0) throw new RuntimeException('Giá và mức tồn tối thiểu không được âm.');
        if(!$this->find($id)) throw new RuntimeException('Không tìm thấy hàng hóa.');
        $this->assertCodeFree($ma,$id);
        $st=$this->db->prepare("UPDATE hang_hoa SET ma_hang=?,ten_hang=?,nhom_hang_id=?,don_vi_id=?,gia_nhap=?,gia_ban=?,muc_ton_toi_thieu=?,quan_ly_ton_kho=?,mo_ta=? WHERE hang_hoa_id=?");
        $st->execute([$ma,$ten,($d['nhom_hang_id']??'')!==''?(int)$d['nhom_hang_id']:null,($d['don_vi_id']??'')!==''?(int)$d['don_vi_id']:null,$nhap,$ban,$min,!empty($d['quan_ly_ton_kho'])?1:0,trim((string)($d['mo_ta']??''))?:null,$id]);
    }
    /** Số nơi đang dùng hàng hóa này (phiếu sửa, hóa đơn, phiếu kho). */
    public function usage(int $id): array {
        $q=function(string $sql) use($id){ $st=$this->db->prepare($sql); $st->execute([$id]); return (int)$st->fetchColumn(); };
        $u=['repairs'=>$q("SELECT COUNT(*) FROM chi_tiet_sua_chua WHERE hang_hoa_id=?"),'invoices'=>$q("SELECT COUNT(*) FROM chi_tiet_hoa_don WHERE hang_hoa_id=?"),'receipts'=>$q("SELECT COUNT(*) FROM chi_tiet_phieu_kho WHERE hang_hoa_id=?")];
        $u['total']=$u['repairs']+$u['invoices']+$u['receipts']; return $u;
    }
    public function setActive(int $id,bool $active): void {
        $st=$this->db->prepare("UPDATE hang_hoa SET trang_thai=? WHERE hang_hoa_id=?"); $st->execute([$active?1:0,$id]);
        if(!$this->find($id)) throw new RuntimeException('Không tìm thấy hàng hóa.');
    }
    /** Xóa hẳn hàng hóa chưa từng phát sinh giao dịch. Đã có giao dịch thì phải dùng "Ngừng kinh doanh". Trả về tên hàng đã xóa. */
    public function delete(int $id): string {
        $this->db->beginTransaction();
        try{
            $st=$this->db->prepare("SELECT ma_hang,ten_hang FROM hang_hoa WHERE hang_hoa_id=? FOR UPDATE"); $st->execute([$id]); $h=$st->fetch();
            if(!$h) throw new RuntimeException('Không tìm thấy hàng hóa (có thể đã bị xóa).');
            $u=$this->usage($id);
            if($u['total']>0) throw new RuntimeException('Hàng này đã phát sinh giao dịch ('.$u['repairs'].' dòng phiếu sửa, '.$u['invoices'].' dòng hóa đơn, '.$u['receipts'].' dòng phiếu kho) nên không thể xóa. Hãy dùng "Ngừng kinh doanh" để ẩn khỏi danh sách.');
            $this->db->prepare("DELETE FROM hang_hoa WHERE hang_hoa_id=?")->execute([$id]);
            $this->db->commit(); return $h['ma_hang'].' — '.$h['ten_hang'];
        }catch(Throwable $e){ if($this->db->inTransaction()) $this->db->rollBack(); throw $e; }
    }
    /** Kiểm kê: đặt tồn kho thực tế. Tạo phiếu kho "Điều chỉnh" ghi vết chênh lệch. Trả về chênh lệch. */
    public function setStock(int $id,float $newQty,string $reason=''): float {
        $newQty=round($newQty,3);
        if($newQty<0) throw new RuntimeException('Tồn kho thực tế không được âm.');
        $this->db->beginTransaction();
        try{
            $st=$this->db->prepare("SELECT ton_kho,quan_ly_ton_kho,gia_nhap FROM hang_hoa WHERE hang_hoa_id=? FOR UPDATE"); $st->execute([$id]); $h=$st->fetch();
            if(!$h) throw new RuntimeException('Không tìm thấy hàng hóa.');
            if((int)$h['quan_ly_ton_kho']!==1) throw new RuntimeException('Hàng này không quản lý tồn kho.');
            $cur=(float)$h['ton_kho']; $delta=round($newQty-$cur,3);
            if(abs($delta)<0.0005) throw new RuntimeException('Tồn kho thực tế bằng tồn hiện tại, không có gì để điều chỉnh.');
            $reason=trim($reason)!==''?mb_substr(trim($reason),0,255):'Kiểm kê điều chỉnh tồn kho';
            $this->db->prepare("INSERT INTO phieu_kho(ma_phieu,loai_phieu,ly_do,tham_chieu) VALUES(LEFT(UUID(),30),'DIEU_CHINH',?,?)")->execute([$reason,'KIEM_KE']);
            $pid=(int)$this->db->lastInsertId();
            $this->db->prepare("UPDATE phieu_kho SET ma_phieu=? WHERE phieu_kho_id=?")->execute(['DC'.str_pad((string)$pid,5,'0',STR_PAD_LEFT),$pid]);
            $this->db->prepare("INSERT INTO chi_tiet_phieu_kho(phieu_kho_id,hang_hoa_id,so_luong,don_gia,ghi_chu) VALUES(?,?,?,?,?)")->execute([$pid,$id,$delta,$h['gia_nhap'],'Kiểm kê: từ '.rtrim(rtrim(number_format($cur,3,'.',''),'0'),'.').' thành '.rtrim(rtrim(number_format($newQty,3,'.',''),'0'),'.')]);
            $this->db->prepare("UPDATE hang_hoa SET ton_kho=? WHERE hang_hoa_id=?")->execute([$newQty,$id]);
            $this->db->commit(); return $delta;
        }catch(Throwable $e){ if($this->db->inTransaction()) $this->db->rollBack(); throw $e; }
    }
    public function detail(int $id): ?array { $st=$this->db->prepare("SELECT h.*,nh.ten_nhom,dv.ten_don_vi FROM hang_hoa h LEFT JOIN nhom_hang nh ON nh.nhom_hang_id=h.nhom_hang_id LEFT JOIN don_vi_tinh dv ON dv.don_vi_id=h.don_vi_id WHERE h.hang_hoa_id=?"); $st->execute([$id]); $h=$st->fetch(); if(!$h)return null; $st=$this->db->prepare("SELECT pk.*,ct.so_luong,ct.don_gia,ct.ghi_chu FROM chi_tiet_phieu_kho ct JOIN phieu_kho pk ON pk.phieu_kho_id=ct.phieu_kho_id WHERE ct.hang_hoa_id=? ORDER BY pk.ngay_lap DESC,pk.phieu_kho_id DESC LIMIT 100"); $st->execute([$id]); return ['hang'=>$h,'movements'=>$st->fetchAll()]; }
    public function createReceipt(string $type,array $items,string $reason=''): int {
        if(!in_array($type,['NHAP','XUAT','DIEU_CHINH'],true)) throw new RuntimeException('Loại phiếu kho không hợp lệ.');
        $valid=[]; foreach($items as $it){$id=(int)($it['hang_hoa_id']??0);$qty=(float)($it['so_luong']??0);$price=(float)($it['don_gia']??0);if($id&&($type==='DIEU_CHINH'?$qty!=0.0:$qty>0))$valid[]=['id'=>$id,'qty'=>$qty,'price'=>$price,'note'=>trim((string)($it['ghi_chu']??''))];}
        if(!$valid) throw new RuntimeException('Phiếu kho chưa có hàng hóa.');
        $this->db->beginTransaction();
        try {
            $st=$this->db->prepare("INSERT INTO phieu_kho(ma_phieu,loai_phieu,ly_do,tham_chieu) VALUES(LEFT(UUID(),30),?,?,?)"); $st->execute([$type,trim($reason)?:null,'']); $pid=(int)$this->db->lastInsertId();
            $ma=($type==='NHAP'?'NK':($type==='XUAT'?'XK':'DC')).str_pad((string)$pid,5,'0',STR_PAD_LEFT); $this->db->prepare("UPDATE phieu_kho SET ma_phieu=? WHERE phieu_kho_id=?")->execute([$ma,$pid]);
            foreach($valid as $it){
                $lock=$this->db->prepare("SELECT ton_kho,quan_ly_ton_kho FROM hang_hoa WHERE hang_hoa_id=? FOR UPDATE");$lock->execute([$it['id']]);$h=$lock->fetch();if(!$h)throw new RuntimeException('Có hàng hóa không tồn tại.');
                $delta=$type==='NHAP'?$it['qty']:($type==='XUAT'?- $it['qty']:$it['qty']);
                if($type==='XUAT' && (int)$h['quan_ly_ton_kho']===1 && (float)$h['ton_kho'] < $it['qty']) throw new RuntimeException('Không đủ tồn kho để xuất.');
                if($type==='DIEU_CHINH' && $delta<0 && (int)$h['quan_ly_ton_kho']===1 && (float)$h['ton_kho']+$delta<0) throw new RuntimeException('Điều chỉnh làm tồn kho âm.');
                $this->db->prepare("INSERT INTO chi_tiet_phieu_kho(phieu_kho_id,hang_hoa_id,so_luong,don_gia,ghi_chu) VALUES(?,?,?,?,?)")->execute([$pid,$it['id'],$it['qty'],$it['price'],$it['note']?:null]);
                $this->db->prepare("UPDATE hang_hoa SET ton_kho=ton_kho+? WHERE hang_hoa_id=?")->execute([$delta,$it['id']]);
            }
            $this->db->commit(); return $pid;
        } catch(Throwable $e){$this->db->rollBack();throw $e;}
    }
    public function lowStock(): array { return $this->db->query("SELECT h.hang_hoa_id,h.ma_hang,h.ten_hang,h.ton_kho,h.muc_ton_toi_thieu,COALESCE(dv.ten_don_vi,'') ten_don_vi FROM hang_hoa h LEFT JOIN don_vi_tinh dv ON dv.don_vi_id=h.don_vi_id WHERE h.trang_thai=1 AND h.quan_ly_ton_kho=1 AND h.ton_kho<=h.muc_ton_toi_thieu ORDER BY h.ton_kho ASC,h.ten_hang LIMIT 20")->fetchAll(); }
}
