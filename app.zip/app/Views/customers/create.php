<?php
$h=fn($v)=>htmlspecialchars((string)$v);
$mode=$form['mode']; $cust=$form['customer']; $base=$h($config['base_url']);
$vehBlock=function(string $idx,array $v) use($h){ ob_start(); ?>
<div class="veh-block border rounded-2xl p-5 bg-slate-50" data-block>
  <div class="flex items-center justify-between mb-4"><div class="font-bold text-slate-700">🚗 Xe <span class="veh-no"></span></div><button type="button" class="veh-remove text-sm text-red-600 hover:underline">Xóa xe này</button></div>
  <div class="grid md:grid-cols-3 gap-4 mb-4">
    <div><label class="label">Biển số *</label><input name="xe[<?=$idx?>][bien_so_hien_tai]" value="<?=$h($v['bien_so_hien_tai']??'')?>" class="input uppercase" placeholder="VD: 51H-123.45"></div>
    <div><label class="label">Loại xe</label><input name="xe[<?=$idx?>][loai_xe]" value="<?=$h($v['loai_xe']??'')?>" class="input" placeholder="Xe tải, bán tải..."></div>
    <div><label class="label">Năm sản xuất</label><input type="number" name="xe[<?=$idx?>][nam_san_xuat]" value="<?=$h($v['nam_san_xuat']??'')?>" min="1900" max="2100" class="input"></div>
  </div>
  <div class="grid md:grid-cols-3 gap-4 mb-4">
    <div><label class="label">Nhãn hiệu</label><input name="xe[<?=$idx?>][nhan_hieu]" value="<?=$h($v['nhan_hieu']??'')?>" class="input"></div>
    <div><label class="label">Model</label><input name="xe[<?=$idx?>][model]" value="<?=$h($v['model']??'')?>" class="input"></div>
    <div><label class="label">Màu xe</label><input name="xe[<?=$idx?>][mau_xe]" value="<?=$h($v['mau_xe']??'')?>" class="input"></div>
  </div>
  <div class="grid md:grid-cols-3 gap-4">
    <div><label class="label">Số khung</label><input name="xe[<?=$idx?>][so_khung]" value="<?=$h($v['so_khung']??'')?>" class="input"></div>
    <div><label class="label">Số máy</label><input name="xe[<?=$idx?>][so_may]" value="<?=$h($v['so_may']??'')?>" class="input"></div>
    <div><label class="label">Ghi chú xe</label><input name="xe[<?=$idx?>][ghi_chu]" value="<?=$h($v['ghi_chu']??'')?>" class="input"></div>
  </div>
</div>
<?php return ob_get_clean(); };
?>
<div class="max-w-4xl mx-auto">
  <div class="mb-6"><p class="text-sm text-slate-500">Khách hàng &amp; xe</p><h1 class="text-2xl font-black">Thêm khách hàng &amp; xe</h1><p class="text-slate-500 text-sm mt-1">Nhập khách hàng và xe của họ trong một lần. Có thể thêm nhiều xe, hoặc chọn khách hàng đã có để thêm xe mới.</p></div>
  <?php if($error): ?><div class="mb-5 p-4 rounded-xl bg-red-50 text-red-700 border border-red-200"><?=$h($error)?></div><?php endif; ?>
  <form method="post" id="comboForm" class="space-y-6">
    <section class="bg-white rounded-2xl border p-6">
      <div class="flex flex-wrap items-center justify-between gap-3 mb-5">
        <h2 class="section-title">1. Khách hàng / chủ xe</h2>
        <?php if($canCustomer): ?>
        <div class="inline-flex rounded-xl border overflow-hidden text-sm font-semibold">
          <label class="px-4 py-2 cursor-pointer has-[:checked]:bg-blue-600 has-[:checked]:text-white"><input type="radio" name="customer_mode" value="new" class="sr-only" <?=$mode==='new'?'checked':''?>>Khách hàng mới</label>
          <label class="px-4 py-2 cursor-pointer border-l has-[:checked]:bg-blue-600 has-[:checked]:text-white"><input type="radio" name="customer_mode" value="existing" class="sr-only" <?=$mode==='existing'?'checked':''?>>Khách hàng có sẵn</label>
        </div>
        <?php else: ?><input type="hidden" name="customer_mode" value="existing"><?php endif; ?>
      </div>
      <?php if($canCustomer): ?>
      <div id="newCustomer" class="space-y-4">
        <div><label class="label">Họ tên *</label><input name="ho_ten" value="<?=$h($cust['ho_ten']??'')?>" class="input" autofocus></div>
        <div class="grid md:grid-cols-2 gap-4">
          <div><label class="label">Số điện thoại</label><input name="so_dien_thoai" value="<?=$h($cust['so_dien_thoai']??'')?>" class="input"></div>
          <div><label class="label">Địa chỉ</label><input name="dia_chi" value="<?=$h($cust['dia_chi']??'')?>" class="input"></div>
        </div>
        <div><label class="label">Ghi chú khách hàng</label><textarea name="ghi_chu" rows="2" class="input"><?=$h($cust['ghi_chu']??'')?></textarea></div>
      </div>
      <?php endif; ?>
      <div id="existingCustomer" class="space-y-3">
        <input type="text" id="custFilter" class="input" placeholder="Gõ tên, SĐT hoặc mã để lọc danh sách...">
        <select name="khach_hang_id" id="custSelect" class="input">
          <option value="">— Chọn khách hàng —</option>
          <?php foreach($customers as $c): ?><option value="<?=$c['khach_hang_id']?>" <?=$form['khach_hang_id']==(int)$c['khach_hang_id']?'selected':''?>><?=$h($c['ma_kh'].' — '.$c['ho_ten'].($c['so_dien_thoai']?' · '.$c['so_dien_thoai']:''))?></option><?php endforeach; ?>
        </select>
      </div>
    </section>

    <?php if($canVehicle): ?>
    <section class="bg-white rounded-2xl border p-6">
      <div class="flex items-center justify-between mb-5"><h2 class="section-title">2. Xe của khách <span class="text-sm font-normal text-slate-400">(không bắt buộc)</span></h2><button type="button" id="addVeh" class="btn-secondary text-sm">+ Thêm xe khác</button></div>
      <div id="vehList" class="space-y-4">
        <?php foreach($form['vehicles'] as $i=>$v) echo $vehBlock((string)$i,$v); ?>
      </div>
      <template id="vehTpl"><?=$vehBlock('__IDX__',[])?></template>
    </section>
    <?php endif; ?>

    <div class="flex flex-wrap justify-end gap-3">
      <a href="<?=$base?>/khach-hang" class="px-5 py-3 rounded-xl border bg-white">Hủy</a>
      <button name="next" value="save" class="px-5 py-3 rounded-xl bg-blue-600 text-white font-semibold">Lưu</button>
      <?php if($canVehicle && Permissions::can('repairs')): ?><button name="next" value="repair" class="px-5 py-3 rounded-xl bg-emerald-600 text-white font-semibold">Lưu &amp; tiếp nhận xe sửa chữa →</button><?php endif; ?>
    </div>
  </form>
</div>
<script>
document.addEventListener('DOMContentLoaded',()=>{
  const form=document.getElementById('comboForm');
  const radios=form.querySelectorAll('input[name=customer_mode]');
  const boxNew=document.getElementById('newCustomer'), boxOld=document.getElementById('existingCustomer');
  const name=form.querySelector('input[name=ho_ten]'), sel=document.getElementById('custSelect');
  function mode(){const r=form.querySelector('input[name=customer_mode]:checked')||form.querySelector('input[name=customer_mode][type=hidden]');return r?r.value:'existing';}
  function applyMode(){const m=mode();if(boxNew)boxNew.style.display=m==='new'?'':'none';boxOld.style.display=m==='existing'?'':'none';if(name)name.required=m==='new';sel.required=m==='existing';}
  radios.forEach(r=>r.addEventListener('change',applyMode));applyMode();
  // lọc danh sách khách có sẵn
  const all=[...sel.options].map(o=>({v:o.value,t:o.text}));
  document.getElementById('custFilter').addEventListener('input',e=>{const q=e.target.value.trim().toLowerCase(),cur=sel.value;sel.innerHTML='';all.filter(o=>o.v===''||o.t.toLowerCase().includes(q)).forEach(o=>{const op=new Option(o.t,o.v);if(o.v===cur)op.selected=true;sel.add(op);});});
  // thêm / xóa xe
  const list=document.getElementById('vehList'),tpl=document.getElementById('vehTpl'),add=document.getElementById('addVeh');
  if(!list)return;
  let idx=list.querySelectorAll('[data-block]').length+100;
  function renumber(){list.querySelectorAll('[data-block]').forEach((b,i)=>{b.querySelector('.veh-no').textContent=i+1;});}
  function addBlock(){if(list.querySelectorAll('[data-block]').length>=10){alert('Tối đa 10 xe mỗi lần.');return;}const d=document.createElement('div');d.innerHTML=tpl.innerHTML.replaceAll('__IDX__',String(idx++));list.appendChild(d.firstElementChild);renumber();}
  add.addEventListener('click',addBlock);
  list.addEventListener('click',e=>{const b=e.target.closest('.veh-remove');if(!b)return;const blocks=list.querySelectorAll('[data-block]');const blk=b.closest('[data-block]');if(blocks.length<=1){blk.querySelectorAll('input').forEach(i=>i.value='');}else{blk.remove();}renumber();});
  renumber();
});
</script>
