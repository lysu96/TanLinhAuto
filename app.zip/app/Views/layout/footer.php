</div></main></div><script src="<?=htmlspecialchars($config['base_url'])?>/assets/js/app.js"></script></body></html>
