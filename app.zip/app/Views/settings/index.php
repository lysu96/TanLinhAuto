<div class="max-w-5xl mx-auto">
  <div class="mb-6"><p class="text-sm text-blue-600 font-semibold">THIẾT LẬP HỆ THỐNG</p><h1 class="text-3xl font-black mt-1">Thông tin gara</h1><p class="text-slate-500 mt-1">Thông tin này sẽ được dùng trên giao diện và các mẫu in.</p></div>
  <?php if($error):?><div class="mb-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3"><?=htmlspecialchars($error)?></div><?php endif;?>
  <?php if($success):?><div class="mb-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3"><?=htmlspecialchars($success)?></div><?php endif;?>
  <form method="post" enctype="multipart/form-data" class="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 space-y-6">
    <div class="grid md:grid-cols-2 gap-5">
      <label class="block"><span class="text-sm font-semibold">Tên gara *</span><input required name="ten_gara" value="<?=htmlspecialchars($settings['ten_gara']??'')?>" class="mt-2 w-full rounded-xl border px-4 py-3 outline-none focus:border-blue-500"></label>
      <label class="block"><span class="text-sm font-semibold">Số điện thoại</span><input name="so_dien_thoai" value="<?=htmlspecialchars($settings['so_dien_thoai']??'')?>" class="mt-2 w-full rounded-xl border px-4 py-3"></label>
      <label class="block md:col-span-2"><span class="text-sm font-semibold">Địa chỉ</span><input name="dia_chi" value="<?=htmlspecialchars($settings['dia_chi']??'')?>" class="mt-2 w-full rounded-xl border px-4 py-3"></label>
      <label class="block"><span class="text-sm font-semibold">Email</span><input type="email" name="email" value="<?=htmlspecialchars($settings['email']??'')?>" class="mt-2 w-full rounded-xl border px-4 py-3"></label>
      <label class="block"><span class="text-sm font-semibold">Mã số thuế</span><input name="ma_so_thue" value="<?=htmlspecialchars($settings['ma_so_thue']??'')?>" class="mt-2 w-full rounded-xl border px-4 py-3"></label>
      <label class="block"><span class="text-sm font-semibold">Website</span><input name="website" value="<?=htmlspecialchars($settings['website']??'')?>" class="mt-2 w-full rounded-xl border px-4 py-3"></label>
      <label class="block"><span class="text-sm font-semibold">Logo</span><input type="file" name="logo" accept="image/png,image/jpeg,image/webp" class="mt-2 w-full rounded-xl border px-4 py-2.5 bg-white"><span class="text-xs text-slate-400">PNG/JPG/WEBP, tối đa 2MB.</span></label>
    </div>
    <label class="block"><span class="text-sm font-semibold">Ghi chú / thông tin chân trang</span><textarea name="ghi_chu" rows="4" class="mt-2 w-full rounded-xl border px-4 py-3"><?=htmlspecialchars($settings['ghi_chu']??'')?></textarea></label>
    <?php if(!empty($settings['logo'])):?><div class="flex items-center gap-4"><img src="<?=htmlspecialchars($settings['logo'])?>" class="h-20 max-w-64 object-contain rounded-xl border p-2 bg-white"><span class="text-sm text-slate-500">Logo hiện tại</span></div><?php endif;?>
    <div class="flex justify-end"><button class="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold">Lưu thông tin gara</button></div>
  </form>
</div>
