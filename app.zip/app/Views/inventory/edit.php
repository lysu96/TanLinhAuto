<?php $v=fn($k)=>htmlspecialchars((string)($h[$k]??'')); ?>
<div class="max-w-4xl"><h1 class="text-2xl font-black mb-1">Sửa hàng hóa</h1><p class="text-slate-500 mb-6">Cập nhật thông tin hàng hóa. Tồn kho hiện tại: <b><?=$v('ton_kho')?></b> — muốn đổi số lượng hãy dùng <b>Kiểm kê / điều chỉnh tồn</b> ở trang chi tiết để có phiếu kho ghi vết. Đổi giá không ảnh hưởng các phiếu, hóa đơn đã lập.</p>
<?php if($error): ?><div class="mb-4 bg-red-50 text-red-700 border border-red-200 rounded-xl p-3"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="post" class="bg-white border rounded-2xl p-6 grid md:grid-cols-2 gap-5">
<label>Mã hàng<input name="ma_hang" required maxlength="30" value="<?=$v('ma_hang')?>" class="mt-1 w-full border rounded-xl px-4 py-2.5"></label>
<label>Tên hàng<input name="ten_hang" required maxlength="255" value="<?=$v('ten_hang')?>" class="mt-1 w-full border rounded-xl px-4 py-2.5"></label>
<label>Nhóm<select name="nhom_hang_id" class="mt-1 w-full border rounded-xl px-4 py-2.5"><option value="">-- Chọn --</option><?php foreach($groups as $g): ?><option value="<?=$g['nhom_hang_id']?>" <?=(string)($h['nhom_hang_id']??'')===(string)$g['nhom_hang_id']?'selected':''?>><?=htmlspecialchars($g['ten_nhom'])?></option><?php endforeach;?></select></label>
<label>Đơn vị<select name="don_vi_id" class="mt-1 w-full border rounded-xl px-4 py-2.5"><option value="">-- Chọn --</option><?php foreach($units as $u): ?><option value="<?=$u['don_vi_id']?>" <?=(string)($h['don_vi_id']??'')===(string)$u['don_vi_id']?'selected':''?>><?=htmlspecialchars($u['ten_don_vi'])?></option><?php endforeach;?></select></label>
<label>Giá nhập<input name="gia_nhap" type="number" step="any" min="0" value="<?=$v('gia_nhap')?>" class="mt-1 w-full border rounded-xl px-4 py-2.5"></label>
<label>Giá bán<input name="gia_ban" type="number" step="any" min="0" value="<?=$v('gia_ban')?>" class="mt-1 w-full border rounded-xl px-4 py-2.5"></label>
<label>Mức tồn tối thiểu<input name="muc_ton_toi_thieu" type="number" step="any" min="0" value="<?=$v('muc_ton_toi_thieu')?>" class="mt-1 w-full border rounded-xl px-4 py-2.5"></label>
<label class="flex gap-3 items-center md:mt-8"><input type="checkbox" name="quan_ly_ton_kho" value="1" <?=!empty($h['quan_ly_ton_kho'])?'checked':''?>> Quản lý tồn kho</label>
<label class="md:col-span-2">Mô tả<textarea name="mo_ta" rows="3" class="mt-1 w-full border rounded-xl px-4 py-2.5"><?=$v('mo_ta')?></textarea></label>
<div class="md:col-span-2 flex gap-2"><a href="<?=$config['base_url']?>/hang-hoa/<?=(int)$h['hang_hoa_id']?>" class="px-5 py-2.5 rounded-xl border">Hủy</a><button class="px-5 py-2.5 rounded-xl bg-blue-600 text-white font-semibold">Lưu thay đổi</button></div></form></div>
