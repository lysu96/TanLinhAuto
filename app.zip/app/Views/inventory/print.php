<?php $first=$rows[0]; $total=0; foreach($rows as $r){$total += (float)$r['so_luong']*(float)$r['don_gia'];} $s=$settings; ?>
<div class="print-sheet bg-white mx-auto p-8 max-w-4xl">
  <div class="flex items-start justify-between border-b-2 border-slate-800 pb-4 mb-5">
    <div class="flex items-center gap-4">
      <?php if(!empty($s['logo'])): ?><img src="<?=htmlspecialchars($s['logo'])?>" class="w-16 h-16 object-contain" alt="Logo"><?php endif; ?>
      <div><div class="text-2xl font-black"><?=htmlspecialchars($s['ten_gara']??'TÂN LINH AUTO')?></div><div class="text-xs text-slate-600"><?=htmlspecialchars($s['dia_chi']??'')?></div><div class="text-xs text-slate-600">SĐT: <?=htmlspecialchars($s['so_dien_thoai']??'')?> <?=!empty($s['email'])?' · '.htmlspecialchars($s['email']):''?></div></div>
    </div>
    <div class="text-right"><div class="font-bold">PHIẾU KHO</div><div class="text-xl font-black"><?=htmlspecialchars($first['ma_phieu'])?></div><div class="text-sm">Ngày <?=date('d/m/Y H:i',strtotime($first['ngay_lap']))?></div></div>
  </div>
  <div class="grid grid-cols-2 gap-4 text-sm mb-5"><div><b>Loại phiếu:</b> <?=htmlspecialchars($first['loai_phieu'])?></div><div><b>Lý do:</b> <?=htmlspecialchars($first['ly_do']??'')?></div></div>
  <table class="w-full text-sm border-collapse"><thead><tr><th class="border p-2">STT</th><th class="border p-2 text-left">Mã hàng</th><th class="border p-2 text-left">Tên hàng</th><th class="border p-2 text-right">SL</th><th class="border p-2 text-right">Đơn giá</th><th class="border p-2 text-right">Thành tiền</th></tr></thead><tbody>
  <?php foreach($rows as $i=>$r): ?><tr><td class="border p-2 text-center"><?=$i+1?></td><td class="border p-2"><?=htmlspecialchars($r['ma_hang'])?></td><td class="border p-2"><?=htmlspecialchars($r['ten_hang'])?></td><td class="border p-2 text-right"><?=rtrim(rtrim(number_format((float)$r['so_luong'],3,'.',','),'0'),'.')?></td><td class="border p-2 text-right"><?=number_format((float)$r['don_gia'],0,',','.')?></td><td class="border p-2 text-right"><?=number_format((float)$r['so_luong']*(float)$r['don_gia'],0,',','.')?></td></tr><?php endforeach; ?>
  </tbody><tfoot><tr><td colspan="5" class="border p-2 text-right font-bold">TỔNG GIÁ TRỊ</td><td class="border p-2 text-right font-black"><?=number_format($total,0,',','.')?> đ</td></tr></tfoot></table>
  <div class="grid grid-cols-3 gap-8 text-center text-sm mt-14"><div>Người lập phiếu<br><br><br><b>(Ký, ghi rõ họ tên)</b></div><div>Người giao / nhận<br><br><br><b>(Ký, ghi rõ họ tên)</b></div><div>Đại diện gara<br><br><br><b><?=htmlspecialchars($s['ten_gara']??'TÂN LINH AUTO')?></b></div></div>
</div><div class="no-print fixed bottom-5 right-5"><button onclick="window.print()" class="btn-primary">🖨 In phiếu</button></div>
