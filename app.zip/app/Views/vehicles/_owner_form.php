<?php
/* Form chọn/thêm chủ xe dùng chung cho "Gán chủ" và "Đổi chủ".
   Biến cần có: $of = [action,id,submit,date_label,default_mode,exclude], $customers, $canNew, $form */
$same=($form['action']??'')===$of['action'];
$fp=$same?$form['post']:[]; $pid=$of['id'];
$mode=$same?$form['mode']:$of['default_mode']; if(!$canNew) $mode='existing';
$selected=$same?(int)$form['khach_hang_id']:0; $exclude=(int)($of['exclude']??0);
$fh=fn($k)=>htmlspecialchars((string)($fp[$k]??''));
?>
<form method="post" id="<?=$pid?>Form" class="p-5 space-y-5"><input type="hidden" name="action" value="<?=$of['action']?>">
  <?php if($canNew): ?><div class="inline-flex rounded-xl border overflow-hidden text-sm font-semibold">
    <label class="px-4 py-2 cursor-pointer has-[:checked]:bg-blue-600 has-[:checked]:text-white"><input type="radio" name="customer_mode" value="existing" class="sr-only" <?=$mode==='existing'?'checked':''?>>Khách hàng có sẵn</label>
    <label class="px-4 py-2 cursor-pointer border-l has-[:checked]:bg-blue-600 has-[:checked]:text-white"><input type="radio" name="customer_mode" value="new" class="sr-only" <?=$mode==='new'?'checked':''?>>Thêm khách hàng mới</label>
  </div><?php else: ?><input type="hidden" name="customer_mode" value="existing"><?php endif; ?>
  <div id="<?=$pid?>Existing" class="space-y-3">
    <input type="text" id="<?=$pid?>Filter" class="input" placeholder="Gõ tên, SĐT hoặc mã để lọc danh sách...">
    <select name="khach_hang_id" id="<?=$pid?>Select" class="input"><option value="">— Chọn khách hàng —</option><?php foreach($customers as $c): if((int)$c['khach_hang_id']===$exclude) continue; ?><option value="<?=$c['khach_hang_id']?>" <?=$selected===(int)$c['khach_hang_id']?'selected':''?>><?=htmlspecialchars($c['ma_kh'].' — '.$c['ho_ten'].($c['so_dien_thoai']?' · '.$c['so_dien_thoai']:''))?></option><?php endforeach; ?></select>
  </div>
  <?php if($canNew): ?><div id="<?=$pid?>New" class="space-y-4">
    <div><label class="label">Họ tên *</label><input name="ho_ten" value="<?=$fh('ho_ten')?>" class="input"></div>
    <div class="grid md:grid-cols-2 gap-4"><div><label class="label">Số điện thoại</label><input name="so_dien_thoai" value="<?=$fh('so_dien_thoai')?>" class="input"></div><div><label class="label">Địa chỉ</label><input name="dia_chi" value="<?=$fh('dia_chi')?>" class="input"></div></div>
    <div><label class="label">Ghi chú khách hàng</label><input name="ghi_chu" value="<?=$fh('ghi_chu')?>" class="input"></div>
  </div><?php endif; ?>
  <div class="grid md:grid-cols-2 gap-4"><div><label class="label"><?=htmlspecialchars($of['date_label'])?></label><input type="date" name="tu_ngay" max="<?=date('Y-m-d')?>" value="<?=htmlspecialchars((string)($fp['tu_ngay']??date('Y-m-d')))?>" class="input"></div><div><label class="label">Ghi chú</label><input name="ghi_chu_chu_xe" value="<?=$fh('ghi_chu_chu_xe')?>" class="input" placeholder="VD: sang tên, bán xe, khách báo lại..."></div></div>
  <div class="flex justify-end"><button class="btn-primary"><?=htmlspecialchars($of['submit'])?></button></div>
</form>
<script>document.addEventListener('DOMContentLoaded',()=>{const P='<?=$pid?>',f=document.getElementById(P+'Form');if(!f)return;const ex=document.getElementById(P+'Existing'),nw=document.getElementById(P+'New'),sel=document.getElementById(P+'Select'),nm=f.querySelector('input[name=ho_ten]');function mode(){const r=f.querySelector('input[name=customer_mode]:checked')||f.querySelector('input[name=customer_mode][type=hidden]');return r?r.value:'existing';}function apply(){const m=mode();ex.style.display=m==='existing'?'':'none';if(nw)nw.style.display=m==='new'?'':'none';sel.required=m==='existing';if(nm)nm.required=m==='new';}f.querySelectorAll('input[name=customer_mode]').forEach(r=>r.addEventListener('change',apply));apply();const all=[...sel.options].map(o=>({v:o.value,t:o.text}));document.getElementById(P+'Filter').addEventListener('input',e=>{const q=e.target.value.trim().toLowerCase(),cur=sel.value;sel.innerHTML='';all.filter(o=>o.v===''||o.t.toLowerCase().includes(q)).forEach(o=>{const op=new Option(o.t,o.v);if(o.v===cur)op.selected=true;sel.add(op);});});});</script>
