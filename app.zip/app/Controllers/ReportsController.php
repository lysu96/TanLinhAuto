<?php
declare(strict_types=1);
final class ReportsController {
    public function __construct(private PDO $db) {}
    public function index(): void {
        $from=(string)($_GET['from']??date('Y-m-01'));$to=(string)($_GET['to']??date('Y-m-d'));
        if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from))$from=date('Y-m-01');if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to))$to=date('Y-m-d');
        if($from>$to){$tmp=$from;$from=$to;$to=$tmp;}
        $m=new Reports($this->db);View::render('reports/index',['title'=>'Báo cáo','from'=>$from,'to'=>$to,'summary'=>$m->summary($from,$to),'daily'=>$m->daily($from,$to),'items'=>$m->topItems($from,$to),'statuses'=>$m->repairStatus()]);
    }
}
