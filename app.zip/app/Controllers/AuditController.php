<?php
declare(strict_types=1);
final class AuditController {
    public function __construct(private PDO $db) {}
    public function index(): void { if(Permissions::role()!=='ADMIN'){http_response_code(403);View::render('errors/403',['title'=>'Không có quyền']);return;} $q=trim((string)($_GET['q']??''));View::render('admin/audit',['title'=>'Nhật ký hệ thống','logs'=>(new AuditLog($this->db))->list($q),'q'=>$q]); }
}
