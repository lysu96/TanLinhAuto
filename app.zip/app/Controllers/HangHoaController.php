<?php
declare(strict_types=1);
final class HangHoaController {
 public function __construct(private PDO $db) {}
 public function index(): void { $m=new HangHoa($this->db); $flash=$_SESSION['flash_ok']??null; unset($_SESSION['flash_ok']); View::render('inventory/index',['title'=>'Kho hàng','items'=>$m->list(trim((string)($_GET['q']??'')),trim((string)($_GET['stock']??'')),($_GET['inactive']??'')==='1'),'low'=>$m->lowStock(),'flash'=>$flash,'canManage'=>Permissions::can('inventory_manage')]); }
 public function create(): void { $m=new HangHoa($this->db); if($_SERVER['REQUEST_METHOD']==='POST'){try{$id=$m->create($_POST);header('Location: '.$GLOBALS['config']['base_url'].'/hang-hoa/'.$id);exit;}catch(Throwable $e){$error=$e->getMessage();}} View::render('inventory/create',['title'=>'Thêm hàng hóa','groups'=>$m->groups(),'units'=>$m->units(),'error'=>$error??null]); }
 public function show(int $id): void {
  $m=new HangHoa($this->db); $error=null; $canManage=Permissions::can('inventory_manage'); $base=$GLOBALS['config']['base_url'];
  if($_SERVER['REQUEST_METHOD']==='POST'){
   $action=(string)($_POST['action']??'');
   try{
    if($action==='adjust_stock'){
     $delta=$m->setStock($id,(float)str_replace(',','.',(string)($_POST['ton_thuc_te']??'')),trim((string)($_POST['ly_do']??'')));
     Audit::log($this->db,'UPDATE','HANG_HOA','Kiểm kê điều chỉnh tồn kho ('.($delta>0?'+':'').rtrim(rtrim(number_format($delta,3,'.',''),'0'),'.').')','hang_hoa',$id);
     $_SESSION['flash_ok']='Đã cập nhật tồn kho (chênh lệch '.($delta>0?'+':'').rtrim(rtrim(number_format($delta,3,'.',''),'0'),'.').'). Phiếu điều chỉnh đã được ghi vào lịch sử kho.';
     header('Location: '.$base.'/hang-hoa/'.$id);exit;
    }elseif($action==='toggle_active'){
     if(!$canManage) throw new RuntimeException('Bạn không có quyền thay đổi trạng thái hàng hóa.');
     $h=$m->find($id); if(!$h) throw new RuntimeException('Không tìm thấy hàng hóa.');
     $active=(int)$h['trang_thai']!==1; $m->setActive($id,$active);
     Audit::log($this->db,'UPDATE','HANG_HOA',($active?'Kích hoạt lại':'Ngừng kinh doanh').' hàng hóa '.$h['ma_hang'],'hang_hoa',$id);
     $_SESSION['flash_ok']=$active?'Đã kích hoạt lại hàng hóa.':'Đã ngừng kinh doanh. Hàng này sẽ ẩn khỏi danh sách và khi chọn phụ tùng.';
     header('Location: '.$base.'/hang-hoa/'.$id);exit;
    }elseif($action==='delete'){
     if(!$canManage) throw new RuntimeException('Bạn không có quyền xóa hàng hóa.');
     $label=$m->delete($id);
     Audit::log($this->db,'DELETE','HANG_HOA','Xóa hàng hóa '.$label,'hang_hoa',$id);
     $_SESSION['flash_ok']='Đã xóa hàng hóa '.$label.'.';
     header('Location: '.$base.'/hang-hoa');exit;
    }
   }catch(Throwable $e){$error=$e->getMessage();}
  }
  $d=$m->detail($id); if(!$d){http_response_code(404);echo 'Không tìm thấy hàng hóa';return;}
  $flash=$_SESSION['flash_ok']??null; unset($_SESSION['flash_ok']);
  View::render('inventory/show',['title'=>$d['hang']['ten_hang'],'data'=>$d,'usage'=>$m->usage($id),'canManage'=>$canManage,'error'=>$error,'flash'=>$flash]);
 }
 public function edit(int $id): void {
  $m=new HangHoa($this->db); $h=$m->find($id); if(!$h){http_response_code(404);echo 'Không tìm thấy hàng hóa';return;}
  $error=null;
  if($_SERVER['REQUEST_METHOD']==='POST'){
   try{ $m->update($id,$_POST); Audit::log($this->db,'UPDATE','HANG_HOA','Sửa thông tin hàng hóa '.trim((string)($_POST['ma_hang']??'')),'hang_hoa',$id); $_SESSION['flash_ok']='Đã lưu thông tin hàng hóa.'; header('Location: '.$GLOBALS['config']['base_url'].'/hang-hoa/'.$id);exit; }
   catch(Throwable $e){$error=$e->getMessage(); $h=array_merge($h,$_POST,['quan_ly_ton_kho'=>!empty($_POST['quan_ly_ton_kho'])?1:0]);}
  }
  View::render('inventory/edit',['title'=>'Sửa hàng hóa','h'=>$h,'groups'=>$m->groups(),'units'=>$m->units(),'error'=>$error]);
 }
 public function receipt(): void { $m=new HangHoa($this->db); $products=$m->all(); if($_SERVER['REQUEST_METHOD']==='POST'){try{$ids=$_POST['hang_hoa_id']??[];$qty=$_POST['so_luong']??[];$price=$_POST['don_gia']??[];$items=[];foreach($ids as $i=>$id){$items[]=['hang_hoa_id'=>$id,'so_luong'=>$qty[$i]??0,'don_gia'=>$price[$i]??0];}$pid=$m->createReceipt((string)($_POST['loai_phieu']??'NHAP'),$items,(string)($_POST['ly_do']??''));header('Location: '.$GLOBALS['config']['base_url'].'/hang-hoa/phieu-kho/'.$pid);exit;}catch(Throwable $e){$error=$e->getMessage();}} View::render('inventory/receipt',['title'=>'Lập phiếu kho','products'=>$products,'error'=>$error??null]); }
 public function print(int $id): void { $st=$this->db->prepare("SELECT pk.*,ct.hang_hoa_id,ct.so_luong,ct.don_gia,ct.ghi_chu,h.ma_hang,h.ten_hang FROM phieu_kho pk JOIN chi_tiet_phieu_kho ct ON ct.phieu_kho_id=pk.phieu_kho_id JOIN hang_hoa h ON h.hang_hoa_id=ct.hang_hoa_id WHERE pk.phieu_kho_id=?");$st->execute([$id]);$rows=$st->fetchAll();if(!$rows){http_response_code(404);echo 'Không tìm thấy phiếu kho';return;} $settings=(new Settings($this->db))->get(); View::render('inventory/print',['title'=>'In '.$rows[0]['ma_phieu'],'rows'=>$rows,'settings'=>$settings]); }
 public function movement(int $id): void { $st=$this->db->prepare("SELECT pk.*,ct.hang_hoa_id,ct.so_luong,ct.don_gia,ct.ghi_chu,h.ma_hang,h.ten_hang FROM phieu_kho pk JOIN chi_tiet_phieu_kho ct ON ct.phieu_kho_id=pk.phieu_kho_id JOIN hang_hoa h ON h.hang_hoa_id=ct.hang_hoa_id WHERE pk.phieu_kho_id=?");$st->execute([$id]);$rows=$st->fetchAll();if(!$rows){http_response_code(404);echo 'Không tìm thấy phiếu kho';return;}View::render('inventory/movement',['title'=>$rows[0]['ma_phieu'],'rows'=>$rows]); }
}
