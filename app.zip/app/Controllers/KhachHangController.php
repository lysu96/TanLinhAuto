<?php
declare(strict_types=1);
final class KhachHangController {
    public function __construct(private PDO $db) {}
    public function index(): void {
        $q=trim((string)($_GET['q']??''));
        $model=new KhachHang($this->db);
        $customers=$model->list($q, 50);
        View::render('customers/index',['title'=>'Khách hàng','customers'=>$customers,'q'=>$q]);
    }
    /** Màn hình gộp: thêm khách hàng (mới hoặc có sẵn) + một hoặc nhiều xe trong cùng một lần lưu. */
    public function create(): void {
        $error=null;
        $canCustomer=Permissions::can('customers'); $canVehicle=Permissions::can('vehicles');
        $kh=new KhachHang($this->db); $xe=new Xe($this->db);
        $form=[
            'mode'=>(isset($_GET['khach_hang_id'])||(($_GET['mode']??'')==='existing')||!$canCustomer)?'existing':'new',
            'khach_hang_id'=>(int)($_GET['khach_hang_id']??0),
            'customer'=>[],
            'vehicles'=>[[]],
        ];
        if($_SERVER['REQUEST_METHOD']==='POST') {
            $form['mode']=(($_POST['customer_mode']??'new')==='existing')?'existing':'new';
            $form['khach_hang_id']=(int)($_POST['khach_hang_id']??0);
            $form['customer']=$_POST;
            $rows=[]; $keys=['bien_so_hien_tai','loai_xe','nam_san_xuat','nhan_hieu','model','mau_xe','so_khung','so_may','ghi_chu'];
            foreach((array)($_POST['xe']??[]) as $row){
                if(!is_array($row)) continue;
                $clean=[]; $any=false;
                foreach($keys as $k){ $clean[$k]=trim((string)($row[$k]??'')); if($clean[$k]!=='') $any=true; }
                if($any) $rows[]=$clean;
            }
            $form['vehicles']=$rows?:[[]];
            try {
                if(count($rows)>10) throw new RuntimeException('Mỗi lần chỉ thêm tối đa 10 xe.');
                if($rows && !$canVehicle) throw new RuntimeException('Bạn không có quyền thêm xe.');
                $seen=[];
                foreach($rows as $r){
                    $plate=mb_strtoupper($r['bien_so_hien_tai'],'UTF-8');
                    if($plate!=='' && isset($seen[$plate])) throw new RuntimeException('Biển số '.$plate.' bị nhập trùng trong danh sách xe.');
                    $seen[$plate]=true;
                }
                $this->db->beginTransaction();
                if($form['mode']==='existing'){
                    $cid=$form['khach_hang_id'];
                    if($cid<=0 || !$kh->exists($cid)) throw new RuntimeException('Vui lòng chọn khách hàng có sẵn.');
                } else {
                    if(!$canCustomer) throw new RuntimeException('Bạn không có quyền thêm khách hàng mới.');
                    $cid=$kh->insert($_POST);
                }
                $xeIds=[];
                foreach($rows as $r) $xeIds[]=$xe->insert($r,$cid);
                $this->db->commit();
                if($form['mode']==='new') Audit::log($this->db,'CREATE','KHACH_HANG','Thêm khách hàng','khach_hang',$cid);
                foreach($xeIds as $xid) Audit::log($this->db,'CREATE','XE','Thêm xe cho khách hàng #'.$cid,'xe',$xid);
                $base=$GLOBALS['config']['base_url'];
                if(($_POST['next']??'')==='repair' && $xeIds && Permissions::can('repairs')) { header('Location: '.$base.'/phieu-sua/them?xe_id='.$xeIds[0]); exit; }
                header('Location: '.$base.'/khach-hang/'.$cid); exit;
            } catch(Throwable $e){ if($this->db->inTransaction()) $this->db->rollBack(); $error=$e->getMessage(); }
        }
        View::render('customers/create',['title'=>'Thêm khách hàng & xe','error'=>$error,'form'=>$form,'customers'=>$kh->all(),'canCustomer'=>$canCustomer,'canVehicle'=>$canVehicle]);
    }
    public function show(int $id): void {
        $data=(new KhachHang($this->db))->detail($id);
        if(!$data){ http_response_code(404); echo 'Không tìm thấy khách hàng'; return; }
        $hd=new HoaDon($this->db); $error=null;
        if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='refund'){
            try{
                if(!Permissions::can('invoices')) throw new RuntimeException('Bạn không có quyền hoàn tiền cho khách.');
                $amt=$hd->refundCredit($id,(float)($_POST['so_tien']??0),(int)($_POST['phuong_thuc_id']??0),trim((string)($_POST['ghi_chu']??'')));
                $txt=number_format($amt,0,',','.').' đ';
                Audit::log($this->db,'REFUND','SO_DU','Hoàn tiền cho khách '.$txt,'khach_hang',$id);
                $_SESSION['flash_ok']='Đã hoàn '.$txt.' cho khách hàng.';
                header('Location: '.$GLOBALS['config']['base_url'].'/khach-hang/'.$id); exit;
            }catch(Throwable $e){ $error=$e->getMessage(); }
        }
        $flash=$_SESSION['flash_ok']??null; unset($_SESSION['flash_ok']);
        View::render('customers/show',['title'=>$data['customer']['ho_ten'],'customer'=>$data['customer'],'vehicles'=>$data['vehicles'],'repairs'=>$data['repairs'],'invoices'=>$data['invoices'],'invoiceTotals'=>$data['invoiceTotals'],'canInvoices'=>Permissions::can('invoices'),'canRepairs'=>Permissions::can('repairs'),
            'credit'=>$hd->creditBalance($id),'ledger'=>$hd->creditLedger($id,30),'methods'=>$hd->paymentMethods(),'canRefund'=>Permissions::can('invoices'),'error'=>$error,'flash'=>$flash]);
    }
}
