<?php
declare(strict_types=1);
final class AuthController {
    public function __construct(private PDO $db) {}
    public function login(): void {
        if(Auth::check()){ header('Location: '.$GLOBALS['config']['base_url'].'/');exit; }
        $error=null;
        if($_SERVER['REQUEST_METHOD']==='POST'){
            $u=trim((string)($_POST['username']??''));$p=(string)($_POST['password']??'');$m=new AuthModel($this->db);$user=$m->findUser($u);
            if($user && password_verify($p,$user['mat_khau'])){ $m->markLogin((int)$user['tai_khoan_id']);unset($user['mat_khau']);Auth::login($user);Audit::log($this->db,'LOGIN','AUTH','Đăng nhập hệ thống','tai_khoan',(int)$user['tai_khoan_id']);header('Location: '.$GLOBALS['config']['base_url'].'/');exit; }
            $error='Tên đăng nhập hoặc mật khẩu không đúng.';
        }
        View::render('auth/login',['title'=>'Đăng nhập','error'=>$error,'hasAccounts'=>(new AuthModel($this->db))->countAccounts()>0]);
    }
    public function setup(): void {
        $m=new AuthModel($this->db);if($m->countAccounts()>0){header('Location: '.$GLOBALS['config']['base_url'].'/dang-nhap');exit;}
        $error=null;
        if($_SERVER['REQUEST_METHOD']==='POST'){
            $name=trim((string)($_POST['name']??''));$u=trim((string)($_POST['username']??''));$p=(string)($_POST['password']??'');$p2=(string)($_POST['password2']??'');
            if($name===''||$u===''||strlen($p)<6||$p!==$p2)$error='Vui lòng nhập đủ thông tin và mật khẩu tối thiểu 6 ký tự, hai mật khẩu phải giống nhau.';
            else { try{$m->createFirstAdmin($name,$u,$p);header('Location: '.$GLOBALS['config']['base_url'].'/dang-nhap?created=1');exit;}catch(Throwable $e){$error=$e->getMessage();} }
        }
        View::render('auth/setup',['title'=>'Thiết lập quản trị','error'=>$error]);
    }
    public function logout(): void {Auth::logout();header('Location: '.$GLOBALS['config']['base_url'].'/dang-nhap');exit;}
}
