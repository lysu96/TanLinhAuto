<?php
declare(strict_types=1);
final class XeController {
    public function __construct(private PDO $db) {}
    public function index(): void {
        $q=trim((string)($_GET['q']??''));
        $vehicles=(new Xe($this->db))->list($q,50);
        View::render('vehicles/index',['title'=>'Xe & chủ xe','vehicles'=>$vehicles,'q'=>$q]);
    }
    public function create(): void {
        $error=null; $customers=(new KhachHang($this->db))->all();
        if($_SERVER['REQUEST_METHOD']==='POST') {
            try { $id=(new Xe($this->db))->create($_POST); header('Location: '.$GLOBALS['config']['base_url'].'/xe/'.$id); exit; }
            catch(Throwable $e){ $error=$e->getMessage(); }
        }
        View::render('vehicles/create',['title'=>'Thêm xe','error'=>$error,'customers'=>$customers]);
    }
    public function show(int $id): void {
        $xe=new Xe($this->db); $data=$xe->detail($id);
        if(!$data){ http_response_code(404); echo 'Không tìm thấy xe'; return; }
        $error=null; $canNew=Permissions::can('customers'); $kh=new KhachHang($this->db);
        $currentOwnerId=0; foreach($data['owners'] as $o){ if((int)$o['la_chu_hien_tai']===1){ $currentOwnerId=(int)$o['khach_hang_id']; break; } }
        $form=['action'=>'','mode'=>'existing','khach_hang_id'=>0,'post'=>[]];
        $action=(string)($_POST['action']??'');
        if($_SERVER['REQUEST_METHOD']==='POST' && in_array($action,['assign_owner','transfer_owner'],true)){
            $form['action']=$action;
            $form['mode']=(($_POST['customer_mode']??'existing')==='new')?'new':'existing';
            $form['khach_hang_id']=(int)($_POST['khach_hang_id']??0); $form['post']=$_POST;
            try{
                $this->db->beginTransaction();
                $isNew=$form['mode']==='new';
                if($isNew){
                    if(!$canNew) throw new RuntimeException('Bạn không có quyền thêm khách hàng mới.');
                    $cid=$kh->insert($_POST);
                } else {
                    $cid=$form['khach_hang_id'];
                    if($cid<=0) throw new RuntimeException('Vui lòng chọn khách hàng.');
                }
                if($action==='transfer_owner'){
                    $old=$xe->transferOwner($id,$cid,(string)($_POST['tu_ngay']??''),(string)($_POST['ghi_chu_chu_xe']??''));
                } else {
                    $xe->setOwner($id,$cid,(string)($_POST['tu_ngay']??''),(string)($_POST['ghi_chu_chu_xe']??''));
                }
                $this->db->commit();
                if($isNew) Audit::log($this->db,'CREATE','KHACH_HANG','Thêm khách hàng khi '.($action==='transfer_owner'?'đổi chủ xe':'gán chủ xe'),'khach_hang',$cid);
                if($action==='transfer_owner'){
                    Audit::log($this->db,'UPDATE','XE','Đổi chủ xe từ khách hàng #'.$old.' sang #'.$cid,'xe',$id);
                    $_SESSION['flash_ok']='Đã đổi chủ xe. Lịch sử chủ cũ vẫn được lưu bên dưới.';
                } else {
                    Audit::log($this->db,'UPDATE','XE','Gán chủ xe cho khách hàng #'.$cid,'xe',$id);
                    $_SESSION['flash_ok']='Đã cập nhật chủ xe.';
                }
                header('Location: '.$GLOBALS['config']['base_url'].'/xe/'.$id); exit;
            }catch(Throwable $e){ if($this->db->inTransaction()) $this->db->rollBack(); $error=$e->getMessage(); }
        }
        $flash=$_SESSION['flash_ok']??null; unset($_SESSION['flash_ok']);
        View::render('vehicles/show',['title'=>$data['vehicle']['bien_so_hien_tai'],'vehicle'=>$data['vehicle'],'owners'=>$data['owners'],'plates'=>$data['plates'],'repairs'=>$data['repairs'],
            'noOwner'=>empty($data['vehicle']['chu_hien_tai']),'currentOwnerId'=>$currentOwnerId,'customers'=>$kh->all(),'canNew'=>$canNew,'form'=>$form,'error'=>$error,'flash'=>$flash]);
    }
}
