<?php
declare(strict_types=1);
final class HomeController {
    public function __construct(private PDO $db) {}
    public function index(): void {
        $m=new Dashboard($this->db); View::render('dashboard',['title'=>'Tổng quan','stats'=>$m->stats(),'repairs'=>$m->recentRepairs(),'chart'=>$m->chart()]);
    }
}
