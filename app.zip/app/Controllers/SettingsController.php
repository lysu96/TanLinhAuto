<?php
declare(strict_types=1);
final class SettingsController {
    public function __construct(private PDO $db) {}
    public function index(): void {
        Permissions::require('settings');
        $error=null; $success=null; $m=new Settings($this->db); $current=$m->get();
        if($_SERVER['REQUEST_METHOD']==='POST'){
            try {
                $logo=null;
                if(isset($_FILES['logo']) && ($_FILES['logo']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE){
                    if($_FILES['logo']['error']!==UPLOAD_ERR_OK) throw new RuntimeException('Không thể tải logo lên.');
                    if((int)$_FILES['logo']['size']>2*1024*1024) throw new RuntimeException('Logo tối đa 2MB.');
                    $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($_FILES['logo']['tmp_name']);
                    $ext=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'][$mime]??null; if(!$ext) throw new RuntimeException('Logo chỉ hỗ trợ PNG, JPG hoặc WEBP.');
                    $dir=__DIR__.'/../../public/uploads/logo'; if(!is_dir($dir)) mkdir($dir,0755,true); $name='logo_'.bin2hex(random_bytes(8)).'.'.$ext; if(!move_uploaded_file($_FILES['logo']['tmp_name'],$dir.'/'.$name)) throw new RuntimeException('Không lưu được logo.'); $logo=$GLOBALS['config']['base_url'].'/uploads/logo/'.$name;
                }
                $m->save($_POST,$logo); Audit::log($this->db,'UPDATE','SETTINGS','Cập nhật thông tin gara','cai_dat_gara',1); $success='Đã lưu thông tin gara.'; $current=$m->get();
            } catch(Throwable $e){$error=$e->getMessage();}
        }
        View::render('settings/index',['title'=>'Cài đặt gara','settings'=>$current,'error'=>$error,'success'=>$success]);
    }
}
