<?php
declare(strict_types=1);
final class HoaDonController {
    public function __construct(private PDO $db) {}
    private function model(): HoaDon{return new HoaDon($this->db);}
    public function index(): void{$q=trim((string)($_GET['q']??''));$status=trim((string)($_GET['status']??''));$flash=$_SESSION['flash_ok']??null;unset($_SESSION['flash_ok']);View::render('invoices/index',['title'=>'Hóa đơn','invoices'=>$this->model()->list($q,$status),'q'=>$q,'status'=>$status,'flash'=>$flash]);}
    public function create(): void{$m=$this->model();$error=null;if($_SERVER['REQUEST_METHOD']==='POST'){try{$id=$m->createFromRepair((int)$_POST['phieu_sua_id'],(float)($_POST['giam_gia']??0),trim((string)($_POST['ghi_chu']??'')));Audit::log($this->db,'CREATE','HOA_DON','Lập hóa đơn từ phiếu sửa chữa','hoa_don',$id); header('Location: '.rtrim($GLOBALS['config']['base_url'],'/').'/hoa-don/'.$id); exit;}catch(Throwable $e){$error=$e->getMessage();}}View::render('invoices/create',['title'=>'Lập hóa đơn','repairs'=>$m->repairOptions(),'error'=>$error]);}
    public function show(int $id): void{
        $m=$this->model();$data=$m->detail($id);
        if(!$data){http_response_code(404);echo 'Không tìm thấy hóa đơn';return;}
        $error=null;$fmt=fn(float $v)=>number_format($v,0,',','.').' đ';
        if($_SERVER['REQUEST_METHOD']==='POST'){
            $action=(string)($_POST['action']??'');
            try{
                if($action==='pay'){
                    $r=$m->pay($id,(float)($_POST['so_tien']??0),(int)($_POST['phuong_thuc_id']??0),trim((string)($_POST['ma_giao_dich']??'')),trim((string)($_POST['ghi_chu']??'')));
                    Audit::log($this->db,'PAYMENT','HOA_DON','Thu tiền hóa đơn '.$fmt($r['applied']+$r['excess']).($r['excess']>0?' (thừa '.$fmt($r['excess']).' ghi vào số dư khách)':''),'hoa_don',$id);
                    $_SESSION['flash_ok']='Đã thu '.$fmt($r['applied']).' cho hóa đơn.'.($r['excess']>0?' Khách trả thừa '.$fmt($r['excess']).' – đã ghi vào số dư của khách (gara đang nợ khách).':'');
                    header('Location: '.$_SERVER['REQUEST_URI']);exit;
                }elseif($action==='delete_invoice'){
                    if(!Permissions::can('invoices_delete'))throw new RuntimeException('Bạn không có quyền xóa hóa đơn.');
                    $no=(string)$data['h']['so_hoa_don'];
                    if(strcasecmp(trim((string)($_POST['confirm_code']??'')),$no)!==0)throw new RuntimeException('Mã xác nhận không khớp. Hãy gõ đúng số hóa đơn '.$no.' để xóa.');
                    $r=$m->deleteInvoice($id);
                    Audit::log($this->db,'DELETE','HOA_DON','Xóa hóa đơn '.$r['so_hoa_don'].' (khách '.$r['ho_ten'].', tổng '.$fmt($r['tong']).', đã thu '.$fmt($r['paid']).')','hoa_don',$id);
                    $_SESSION['flash_ok']='Đã xóa hóa đơn '.$r['so_hoa_don'].'.'.($r['paid']>0?' Số tiền đã thu '.$fmt($r['paid']).' được chuyển thành số dư của khách '.$r['ho_ten'].' (gara đang nợ khách) — có thể trừ vào hóa đơn khác hoặc hoàn tiền ở trang khách hàng.':'');
                    header('Location: '.$GLOBALS['config']['base_url'].'/hoa-don');exit;
                }elseif($action==='use_credit'){
                    $a=$m->applyCredit($id,(float)($_POST['so_tien']??0));
                    Audit::log($this->db,'PAYMENT','HOA_DON','Trừ số dư khách '.$fmt($a).' vào hóa đơn','hoa_don',$id);
                    $_SESSION['flash_ok']='Đã trừ '.$fmt($a).' từ số dư của khách vào hóa đơn.';
                    header('Location: '.$_SERVER['REQUEST_URI']);exit;
                }
            }catch(Throwable $e){$error=$e->getMessage();}
            $data=$m->detail($id);
        }
        $flash=$_SESSION['flash_ok']??null;unset($_SESSION['flash_ok']);
        View::render('invoices/show',['title'=>'Hóa đơn '.$data['h']['so_hoa_don'],'data'=>$data,'methods'=>$m->paymentMethods(),'error'=>$error,'flash'=>$flash]);
    }
    public function debt(): void{$q=trim((string)($_GET['q']??''));$m=$this->model();View::render('debt/index',['title'=>'Công nợ','customers'=>$m->debtCustomers($q),'credits'=>$m->creditCustomers($q),'q'=>$q]);}
 public function print(int $id):void{$d=(new HoaDon($this->db))->detail($id);if(!$d){http_response_code(404);echo 'Không tìm thấy hóa đơn';return;}View::render('invoices/print',$d+['title'=>'In '.$d['h']['so_hoa_don'],'settings'=>(new Settings($this->db))->get()]);}
}
