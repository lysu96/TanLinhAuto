<?php
declare(strict_types=1);
final class Auth {
    public static function start(): void { if(session_status()===PHP_SESSION_NONE) session_start(); }
    public static function check(): bool { return !empty($_SESSION['user']); }
    public static function user(): ?array { return $_SESSION['user'] ?? null; }
    public static function login(array $user): void { self::start(); $_SESSION['user']=$user; session_regenerate_id(true); }
    public static function logout(): void { self::start(); $_SESSION=[]; if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']); } session_destroy(); }
}
