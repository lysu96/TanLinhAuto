<?php
declare(strict_types=1);
final class Permissions {
    private const MAP = [
        'ADMIN' => ['*'],
        'QUAN_LY' => ['dashboard','customers','vehicles','repairs','repairs_delete','inventory','inventory_manage','invoices','invoices_delete','debt','reports','employees','settings'],
        'KE_TOAN' => ['dashboard','customers','vehicles','invoices','debt','reports','settings'],
        'TIEP_NHAN' => ['dashboard','customers','vehicles','repairs'],
        'THO_SUA' => ['dashboard','vehicles','repairs','inventory'],
    ];
    public static function role(): string { return (string)(Auth::user()['ma_vai_tro'] ?? ''); }
    public static function can(string $permission): bool {
        $role=self::role(); $list=self::MAP[$role]??[]; return in_array('*',$list,true)||in_array($permission,$list,true);
    }
    public static function require(string $permission): void {
        if(!self::can($permission)){ http_response_code(403); View::render('errors/403',['title'=>'Không có quyền','permission'=>$permission]); exit; }
    }
}
