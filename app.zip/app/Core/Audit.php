<?php
declare(strict_types=1);
final class Audit {
    public static function log(PDO $db,string $action,string $module,string $description='',?string $entityType=null,?int $entityId=null): void {
        try {
            $u=Auth::user();
            $st=$db->prepare("INSERT INTO nhat_ky_he_thong(tai_khoan_id,hanh_dong,mo_dun,doi_tuong,doi_tuong_id,mo_ta,ip_address,user_agent) VALUES(?,?,?,?,?,?,?,?)");
            $st->execute([$u['tai_khoan_id']??null,$action,$module,$entityType,$entityId,$description,$_SERVER['REMOTE_ADDR']??null,substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,255)]);
        } catch(Throwable $e) { /* Nhật ký là phần bổ sung; không làm hỏng nghiệp vụ chính nếu bảng chưa migrate. */ }
    }
}
