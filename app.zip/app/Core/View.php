<?php
declare(strict_types=1);
final class View {
    public static function render(string $view, array $data = []): void {
        $config = $GLOBALS['config'] ?? ['app_name'=>'TÂN LINH AUTO','base_url'=>''];
        extract($data);
        require __DIR__ . '/../Views/layout/header.php';
        require __DIR__ . '/../Views/' . $view . '.php';
        require __DIR__ . '/../Views/layout/footer.php';
    }
}
