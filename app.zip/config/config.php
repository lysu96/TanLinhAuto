<?php
declare(strict_types=1);
return [
    'app_name' => 'TÂN LINH AUTO',
    'base_url' => '/TanLinhAuto/public',
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'database' => 'tan_linh_auto',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8mb4',
    ],
];
