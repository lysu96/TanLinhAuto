-- Số dư khách hàng (khách trả thừa -> gara đang nợ khách). Chạy một lần; an toàn nếu chạy lại.
-- Ghi chú: ứng dụng cũng tự tạo bảng này khi cần, file này chỉ để chạy chủ động.
CREATE TABLE IF NOT EXISTS so_du_khach_hang (
  so_du_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  khach_hang_id INT UNSIGNED NOT NULL,
  ngay_phat_sinh DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  loai ENUM('THU_THUA','TRU_HOA_DON','HOAN_TIEN') NOT NULL,
  so_tien DECIMAL(15,2) NOT NULL,
  hoa_don_id INT UNSIGNED NULL,
  phuong_thuc_id SMALLINT UNSIGNED NULL,
  ghi_chu VARCHAR(255) NULL,
  nguoi_tao_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (so_du_id),
  KEY idx_sd_kh (khach_hang_id, ngay_phat_sinh),
  KEY idx_sd_hd (hoa_don_id),
  CONSTRAINT fk_sd_kh FOREIGN KEY (khach_hang_id) REFERENCES khach_hang(khach_hang_id),
  CONSTRAINT fk_sd_hd FOREIGN KEY (hoa_don_id) REFERENCES hoa_don(hoa_don_id),
  CONSTRAINT fk_sd_pt FOREIGN KEY (phuong_thuc_id) REFERENCES phuong_thuc_thanh_toan(phuong_thuc_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO phuong_thuc_thanh_toan(ma_phuong_thuc,ten_phuong_thuc,trang_thai)
SELECT 'SO_DU','Trừ từ số dư khách',1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM phuong_thuc_thanh_toan WHERE ma_phuong_thuc='SO_DU');
