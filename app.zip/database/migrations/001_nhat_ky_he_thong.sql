-- Tùy chọn: chạy một lần trên database tan_linh_auto để bật nhật ký thao tác.
-- Không DROP/ALTER dữ liệu hiện có.
CREATE TABLE IF NOT EXISTS nhat_ky_he_thong (
  nhat_ky_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tai_khoan_id INT(10) UNSIGNED DEFAULT NULL,
  hanh_dong VARCHAR(50) NOT NULL,
  mo_dun VARCHAR(50) NOT NULL,
  doi_tuong VARCHAR(50) DEFAULT NULL,
  doi_tuong_id INT(10) UNSIGNED DEFAULT NULL,
  mo_ta VARCHAR(500) DEFAULT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  user_agent VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (nhat_ky_id),
  KEY idx_nk_tk (tai_khoan_id),
  KEY idx_nk_module (mo_dun),
  KEY idx_nk_created (created_at),
  CONSTRAINT fk_nk_tk FOREIGN KEY (tai_khoan_id) REFERENCES tai_khoan(tai_khoan_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
