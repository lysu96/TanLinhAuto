-- Chạy một lần trên database tan_linh_auto đang dùng. Không xóa/sửa dữ liệu.
-- Sửa v_cong_no_khach_hang: không cộng lặp no_cu và không trừ thanh toán của hóa đơn đã hủy.
CREATE OR REPLACE VIEW v_cong_no_khach_hang AS
SELECT kh.khach_hang_id, kh.ma_kh, kh.ho_ten, kh.so_dien_thoai,
  GREATEST(0,
    COALESCE((SELECT SUM(h.con_no) FROM hoa_don h WHERE h.khach_hang_id=kh.khach_hang_id AND h.trang_thai<>'HUY'),0)
  + COALESCE((SELECT SUM(CASE WHEN c.loai='TANG_NO' THEN c.so_tien ELSE -c.so_tien END) FROM cong_no_dieu_chinh c WHERE c.khach_hang_id=kh.khach_hang_id),0)
  ) AS tong_con_no
FROM khach_hang kh;
